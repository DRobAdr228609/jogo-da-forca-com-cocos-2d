package br.com.enforcado.componente;

import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;
import br.com.enforcado.cenario.menu.CenarioMenuDicasJogo;
import br.com.enforcado.cenario.tela.CenarioTelaFimDoJogo;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.controle.ControleJogo;

public class ComponenteCronometroJogo extends CCLayer{
	
	private long tempoInicial = System.currentTimeMillis();
	private ComponenteCampoTexto cronometro;
	private long minutos;
	private long segundos;
	private boolean utimoMinuto;
	public static boolean fimDoTempo;
	
	public ComponenteCronometroJogo() {
		criaComponentes();
		setButtonspPosition();
		dicionaComponentesNaTela();
		this.schedule("mostraCronometro");
	}

	
	private void dicionaComponentesNaTela() {
		addChild(cronometro);
	}

	
	private void criaComponentes() {
		fimDoTempo = false;
		utimoMinuto = false;
		
		if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.FACIL){
			minutos = 1;
			segundos = 30;
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.MEDIO){
			minutos = 0;
			segundos = 60;
			utimoMinuto = true;
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.DIFICIL){
			minutos = 0;
			segundos = 30;
			utimoMinuto = true;
		}
		
		cronometro = new ComponenteCampoTexto("0", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 20);
	}


	private void setButtonspPosition() {
		cronometro.setPosition( resolucao(CGPoint.ccp(larguraDaCena() / 2 , (alturaDaCena() / 2) + 215) ) );
	}

	public void mostraCronometro(float dt){
		if(ControleJogo.isJogando){
			ccColor3B corDaFonte = ccColor3B.ccWHITE;
			int tamanhoDaFonte = 26;
		
			if (minutos <=0 && getSegundos() > 30){
				corDaFonte = ccColor3B.ccYELLOW;
			}else if (minutos <=0 && getSegundos() <= 30){
				corDaFonte = ccColor3B.ccRED;
			}
			
			if(verificaTempo()){
				removeChild(cronometro , true);
				if (calculaSegundos()>=10){
				cronometro = new ComponenteCampoTexto("0" + getMinutos() + ":" + getSegundos(), ConfiguracaoFontCaminho.FONT_DIGITTAL_DS, corDaFonte, tamanhoDaFonte);
				}else{
				cronometro = new ComponenteCampoTexto("0" + getMinutos() + ":0" + getSegundos(), ConfiguracaoFontCaminho.FONT_DIGITTAL_DS, corDaFonte, tamanhoDaFonte);
			}
				cronometro.setPosition( resolucao(CGPoint.ccp(larguraDaCena() / 2 , (alturaDaCena() / 2) + 215) ) );
				addChild(cronometro);
			}else{
				removeChild(cronometro , true);
				cronometro = new ComponenteCampoTexto("00:00", ConfiguracaoFontCaminho.FONT_DIGITTAL_DS, corDaFonte, tamanhoDaFonte);
				cronometro.setPosition( resolucao(CGPoint.ccp(larguraDaCena() / 2 , (alturaDaCena() / 2) + 215) ) );
				addChild(cronometro);
				
				
				for (ComponenteCampoTexto c : ControleJogo.adicionaLetraNaTelaAposFimDoJogo()) {
					addChild(c);
				}
				
				CCDirector.sharedDirector().replaceScene( CCFadeTransition.transition(4f , CenarioTelaFimDoJogo.criaCenario()));
			}
		}
	}
	
	public int getSegundos() {  
        if(calculaSegundos() >0 ){
        	return (int) calculaSegundos(); 
        }else{
        	tempoInicial = System.currentTimeMillis();
        	utimoMinuto = true;
        	segundos = 60;
        	return 0;
        }
    }  
	
	public int getMinutos() {  
		if (minutos>0){
        	if(calculaSegundos()<=0){
        		--minutos;
        	}
		}
        return (int) minutos;
    }  
	
	private int calculaSegundos(){
		 long milisegundos = System.currentTimeMillis() - tempoInicial;
		return (int) (segundos- Math.round(milisegundos / 1000.0));
	}
	
	private boolean verificaTempo(){
		if (utimoMinuto){
			if (getMinutos()==0 && getSegundos()<=1){
				ControleJogo.verificaJogoRodando(false);
				CenarioMenuDicasJogo.habilitaDesabilitaBotoesJogo(false);
				fimDoTempo = true;
				
			}
		}
		return ControleJogo.isJogando;
	}
	
	
	
}
