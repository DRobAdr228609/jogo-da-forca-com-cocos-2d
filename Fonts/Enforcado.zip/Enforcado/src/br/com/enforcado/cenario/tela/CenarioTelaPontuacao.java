package br.com.enforcado.cenario.tela;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;
import br.com.enforcado.cenario.menu.CenarioMenuPontuacao;
import br.com.enforcado.componente.ComponenteDialogoGrande;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;

public class CenarioTelaPontuacao extends  CCLayer{
	
	public CenarioTelaPontuacao() {
		addChild(new ComponenteDialogoGrande(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_PONTUACAO));
		addChild(new CenarioMenuPontuacao());
	}

	
	/**
	 * Cria a cena e a camada do j
	 * @return
	 */
	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaPontuacao());
		return cena;
	}
}
