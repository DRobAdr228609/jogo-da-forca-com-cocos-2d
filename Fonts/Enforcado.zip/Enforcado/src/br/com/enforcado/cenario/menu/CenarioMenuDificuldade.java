package br.com.enforcado.cenario.menu;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeDownTransition;
import org.cocos2d.transitions.CCJumpZoomTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import android.view.Gravity;
import android.widget.Toast;
import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.componente.ComponenteMenssagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

public class CenarioMenuDificuldade extends CCLayer implements ContratoBotaoMenu{
	
	private ComponenteBotao botaoFacil;
	private ComponenteBotao botaoMedio;
	private ComponenteBotao botaoDificil;
	private ComponenteBotao botaoFechar;
	
	private ComponenteCampoTexto textoBotaoFacil;
	private ComponenteCampoTexto textoBotaoMedio;
	private ComponenteCampoTexto textoBotaoDificil;
	
	private final float scaleX = 0.4f;
	private final float scaleY = 0.5f;
	
	public CenarioMenuDificuldade() {
		this.setIsTouchEnabled(true);
		
		criaComponentes();
		delegaComponentes();
		setButtonspPosition();
		adicionaComponentesNaTela();
	}

	private void adicionaComponentesNaTela() {
		botaoFacil.adicionaBotaoComEfeitoDeBulo();
		addChild(botaoFacil);
		
		textoBotaoFacil.adicionaComEfeitoDeBulo();
		addChild(textoBotaoFacil);
		
		botaoMedio.adicionaBotaoComEfeitoDeBulo();
		addChild(botaoMedio);
		
		textoBotaoMedio.adicionaComEfeitoDeBulo();
		addChild(textoBotaoMedio);
		
		botaoDificil.adicionaBotaoComEfeitoDeBulo();
		addChild(botaoDificil);
		
		textoBotaoDificil.adicionaComEfeitoDeBulo();
		addChild(textoBotaoDificil);
		
		botaoFechar.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoFechar);
	}

	private void delegaComponentes() {
		botaoFacil.setDelegate(this);
		botaoMedio.setDelegate(this);
		botaoDificil.setDelegate(this);
		botaoFechar.setDelegate(this);
	}

	private void criaComponentes() {
		botaoFacil = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO);
		textoBotaoFacil = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DIFICULDADE_NIVEL_FACIL, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		botaoMedio = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO);
		textoBotaoMedio = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DIFICULDADE_NIVEL_MEDIO, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		botaoDificil = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO);
		textoBotaoDificil = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DIFICULDADE_NIVEL_DIFICIL, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		
		if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.FACIL){
			
			botaoFacil = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO);
			
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.MEDIO){
			
			botaoMedio = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO);
			
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.DIFICIL){
			
			botaoDificil = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO);
			
		}
		
		botaoFechar = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_FECHAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18) , scaleX , scaleY);
	}

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setButtonspPosition() {
		botaoFacil.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 3 , (alturaDaCena() / 2) + 50 )));
		botaoMedio.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 3 , alturaDaCena() / 2 )));
		botaoDificil.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 3 , (alturaDaCena()  / 2  ) - 50 )));
		botaoFechar.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /2) - 140 )));
			
		if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.PT_BR)){
			textoBotaoFacil.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 14 , (alturaDaCena() / 2) + 50 )));
			textoBotaoMedio.setPosition(resolucao(CGPoint.ccp((larguraDaCena() / 2) + 14, alturaDaCena() / 2)));
			textoBotaoDificil.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 14, (alturaDaCena() / 2) - 50 )));
			
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.EN_US)){
			
			textoBotaoFacil.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 14 , (alturaDaCena() / 2) + 50 )));
			textoBotaoMedio.setPosition(resolucao(CGPoint.ccp((larguraDaCena() / 2) + 28, alturaDaCena() / 2)));
			textoBotaoDificil.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 14, (alturaDaCena() / 2) - 50 )));
			
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.ES_ES)){
			
			textoBotaoFacil.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 14 , (alturaDaCena() / 2) + 50 )));
			textoBotaoMedio.setPosition(resolucao(CGPoint.ccp((larguraDaCena() / 2) + 30, alturaDaCena() / 2)));
			textoBotaoDificil.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 14, (alturaDaCena() / 2) - 50 )));
			
		}
		
	}
	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		//Executa o som ao clicar no bot�o
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		if (sender.equals(botaoFacil)) {
			ConfiguracaoPreferencias.configuracaoNivelDificuldade(ConfiguracaoPreferencias.FACIL);
			ConfiguracaoPreferencias.salvaPreferencias();

			onCliKcBotao(botaoFacil , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO));
			onCliKcBotao(botaoMedio , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			onCliKcBotao(botaoDificil  , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));			
			CCDirector.sharedDirector().replaceScene( CCJumpZoomTransition.transition(1f , CenarioTelaInicio.criaCenario()));
			ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_SALVA_CONFIGURACAO_NIVEL_DIFICULDADE ,  Gravity.BOTTOM , Toast.LENGTH_SHORT , 1);
			
		}
		
		if (sender.equals(botaoMedio)) {
			ConfiguracaoPreferencias.configuracaoNivelDificuldade(ConfiguracaoPreferencias.MEDIO);
			ConfiguracaoPreferencias.salvaPreferencias();
			
			onCliKcBotao(botaoFacil , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			onCliKcBotao(botaoMedio , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO));
			onCliKcBotao(botaoDificil  , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));			
			CCDirector.sharedDirector().replaceScene( CCJumpZoomTransition.transition(1f , CenarioTelaInicio.criaCenario()));
			ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_SALVA_CONFIGURACAO_NIVEL_DIFICULDADE ,  Gravity.BOTTOM , Toast.LENGTH_SHORT , 1);
		}
		
		if (sender.equals(botaoDificil)) {
			ConfiguracaoPreferencias.configuracaoNivelDificuldade(ConfiguracaoPreferencias.DIFICIL);
			ConfiguracaoPreferencias.salvaPreferencias();

			onCliKcBotao(botaoFacil , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			onCliKcBotao(botaoMedio , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			onCliKcBotao(botaoDificil  , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO));
			
			CCDirector.sharedDirector().replaceScene( CCJumpZoomTransition.transition(1f , CenarioTelaInicio.criaCenario()));
			ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_SALVA_CONFIGURACAO_NIVEL_DIFICULDADE ,  Gravity.BOTTOM , Toast.LENGTH_SHORT , 1);
		}
		
		if (sender.equals(botaoFechar)) {
			onCliKcBotao(botaoFechar , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_FECHAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccGREEN, 18) , scaleX , scaleY));
			CCDirector.sharedDirector().replaceScene( CCFadeDownTransition.transition(0.1f , CenarioTelaInicio.criaCenario()));
		}
		
			
	}
	
	private void onCliKcBotao(ComponenteBotao botaoRemovido , ComponenteBotao novoBotao){
		novoBotao.setDelegate(this);
		novoBotao.setPosition(botaoRemovido.getPosition());
		novoBotao.setIsTouchEnabled(false);
		removeChild(botaoRemovido, true);
		addChild(novoBotao);
	}

}
