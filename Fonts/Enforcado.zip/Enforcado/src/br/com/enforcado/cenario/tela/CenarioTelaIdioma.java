package br.com.enforcado.cenario.tela;
import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;
import br.com.enforcado.cenario.menu.CenarioMenuIdioma;
import br.com.enforcado.componente.ComponenteDialogoGrande;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;

public class CenarioTelaIdioma extends CCLayer{
	
	/**
	 * Configura o cenario na tela de inicial do jogo
	 */
	public CenarioTelaIdioma() {
		addChild(new ComponenteDialogoGrande(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_IDIOMA));
		addChild(new CenarioMenuIdioma());
		
	}
	
	/**
	 * Cria a cena e a camada do cenario configura��es
	 * @return
	 */
	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaIdioma());
		return cena;
	}
	
}
