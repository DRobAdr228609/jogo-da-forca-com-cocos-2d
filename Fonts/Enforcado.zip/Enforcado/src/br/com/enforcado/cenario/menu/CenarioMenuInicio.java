package br.com.enforcado.cenario.menu;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeDownTransition;
import org.cocos2d.transitions.CCSlideInBTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import android.view.Gravity;
import android.widget.Toast;
import br.com.enforcado.cenario.tela.CenarioTelaDificuldade;
import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.cenario.tela.CenarioTelaJogo;
import br.com.enforcado.cenario.tela.CenarioTelaIdioma;
import br.com.enforcado.cenario.tela.CenarioTelaPontuacao;
import br.com.enforcado.cenario.tela.CenarioTelaSair;
import br.com.enforcado.cenario.tela.CenarioTelaSobre;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.componente.ComponenteMenssagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;


public class CenarioMenuInicio extends CCLayer implements ContratoBotaoMenu{
	
	private static ComponenteBotao botaoIniciarPartida;
	private static ComponenteBotao botaoDificuldade;
	private static ComponenteBotao botaoPontuacao;
	private static ComponenteBotao botaoIdioma;
	private static ComponenteBotao botaoSom;
	private static ComponenteBotao botaoSobre;
	private static ComponenteBotao botaoSair;
	private final float scaleX = 0.8f;
	private final float scaleY = 0.7f;
	private boolean isVsializa = true;
	
	public CenarioMenuInicio() {
		this.setIsTouchEnabled(true);
		ConfiguracaoIdioma.carregaTextoIdioma();
		criaComponentes();
		delegaComponentes();
		setButtonspPosition();
		adicionaComponentesNaTela();
		
	}

	private void adicionaComponentesNaTela() {
		botaoIniciarPartida.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoIniciarPartida);
		addChild(botaoDificuldade);
		addChild(botaoPontuacao);
		addChild(botaoSom);
		addChild(botaoSobre);
		addChild(botaoIdioma);
		addChild(botaoSair);
		this.schedule("pulaComTempo" , 2f);
		
	}
	
	public void pulaComTempo(float dt){
		if(isVsializa){
			removeChild(botaoIniciarPartida, true);
			botaoIniciarPartida.adicionaBotaoETextoComEfeitoDeBulo();
			addChild(botaoIniciarPartida);
		}
	}


	private void delegaComponentes() {
		botaoIniciarPartida.setDelegate(this);
		botaoDificuldade.setDelegate(this);
		botaoIdioma.setDelegate(this);
		botaoPontuacao.setDelegate(this);
		botaoSom.setDelegate(this);
		botaoSobre.setDelegate(this);
		botaoSair.setDelegate(this);
	}

	private void criaComponentes() {
		botaoIniciarPartida = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_NOVO_JOGO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES , ccColor3B.ccWHITE, 26) , scaleX ,  scaleY);
		botaoDificuldade = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DIFICULDADE, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES , ccColor3B.ccWHITE, 26)  , scaleX ,  scaleY);
		botaoPontuacao = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_PONTUACAO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES , ccColor3B.ccWHITE, 26) , scaleX ,  scaleY);
		botaoIdioma = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_IDIOMA);
		
		if (ConfiguracaoPreferencias.SOM == true){
			botaoSom = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SOM_ATIVO);
		}else{
			botaoSom = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SOM_DESATIVADO);
		}
		botaoSobre = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SOBRE);
		botaoSair = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SAIR);
	}

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setButtonspPosition() {
		botaoIniciarPartida.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , alturaDaCena() - 205 )));
		botaoDificuldade.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , alturaDaCena() - 280 )));
		botaoPontuacao.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , alturaDaCena() - 355 )));
		botaoSom.setPosition(resolucao(	CGPoint.ccp( (larguraDaCena() / 2)  - 40 , alturaDaCena() - 440 )));
		botaoIdioma.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) - 120 , alturaDaCena() - 440 )));
		botaoSobre.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 40 , alturaDaCena() - 440 )));
		botaoSair.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() /2) + 120 , alturaDaCena() - 440 )));
	}	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		//Executa o som ao clicar no bot�o
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		if (sender.equals(botaoIniciarPartida)) {
			isVsializa = false;
			onCliKcBotao(botaoIniciarPartida , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_NOVO_JOGO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES , ccColor3B.ccGREEN, 26) , scaleX ,  scaleY));
			CCDirector.sharedDirector().replaceScene( CCSlideInBTransition.transition(1.0f , CenarioTelaJogo.criaCenario()));
		}
		
		if (sender.equals(botaoPontuacao)) {
			isVsializa = false;
			onCliKcBotao(botaoPontuacao , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_PONTUACAO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES , ccColor3B.ccGREEN, 26) , scaleX ,  scaleY));
			addChild(CenarioTelaPontuacao.criaCenario());
			desabilitaToqueBotoes(false);
		}
		
		if (sender.equals(botaoDificuldade)) {
			isVsializa = false;
			onCliKcBotao(botaoDificuldade , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DIFICULDADE, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccGREEN, 26)  , scaleX ,  scaleY));
			addChild(CenarioTelaDificuldade.criaCenario());
			desabilitaToqueBotoes(false);
		}
			
		if (sender.equals(botaoIdioma)) {
			isVsializa = false;
			onCliKcBotao(botaoIdioma , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_IDIOMA_CLICKADO));
			addChild(CenarioTelaIdioma.criaCenario());
			desabilitaToqueBotoes(false);
		}
		
		if (sender.equals(botaoSom)) {
			removeChild(botaoSom, true);
			
			if (ConfiguracaoPreferencias.SOM){
				botaoSom = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SOM_ATIVO_CLICKADO);
				ConfiguracaoPreferencias.configuracaoSom(false);
				ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_SALVA_CONFIGURACAO_SOM ,  Gravity.BOTTOM , Toast.LENGTH_SHORT , 2);
			}else{
				botaoSom = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SOM_DESATIVADO_CLICKADO);
				ConfiguracaoPreferencias.configuracaoSom(true);
				ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_SALVA_CONFIGURACAO_SOM ,  Gravity.BOTTOM , Toast.LENGTH_SHORT , 1);
			}
			
			ConfiguracaoSom.somTema();
			ConfiguracaoPreferencias.salvaPreferencias();
			setButtonspPosition();
			addChild(botaoSom);
			CCDirector.sharedDirector().replaceScene( CCFadeDownTransition.transition(0.1f , CenarioTelaInicio.criaCenario()));
			
		}
		
		if (sender.equals(botaoSobre)) {
			isVsializa = false;
			onCliKcBotao(botaoSobre , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SOBRE_CLICKADO));
			addChild(CenarioTelaSobre.criaCenario());
			desabilitaToqueBotoes(false);
		}
		
		if (sender.equals(botaoSair)) {
			isVsializa = false;
			onCliKcBotao(botaoSair , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SAIR_CLICKADO));
			addChild(CenarioTelaSair.criaCenario());
			desabilitaToqueBotoes(false);
		}
			
	}

	public static void desabilitaToqueBotoes(boolean habilitaDesabilita) {
		botaoIniciarPartida.setIsTouchEnabled(habilitaDesabilita);
		botaoDificuldade.setIsTouchEnabled(habilitaDesabilita);
		botaoPontuacao.setIsTouchEnabled(habilitaDesabilita);
		botaoIdioma.setIsTouchEnabled(habilitaDesabilita);
		botaoSom.setIsTouchEnabled(habilitaDesabilita);
		botaoSobre.setIsTouchEnabled(habilitaDesabilita);
		botaoSair.setIsTouchEnabled(habilitaDesabilita);
	}
	
	private void onCliKcBotao(ComponenteBotao botaoRemovido , ComponenteBotao novoBotao){
		novoBotao.setDelegate(this);
		novoBotao.setPosition(botaoRemovido.getPosition());
		novoBotao.setIsTouchEnabled(false);
		removeChild(botaoRemovido, true);
		addChild(novoBotao);
	}
	
}
