package br.com.enforcado.cenario.tela;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;
import org.cocos2d.nodes.CCSprite;
import org.cocos2d.types.CGPoint;
import br.com.enforcado.cenario.menu.CenarioMenuInicio;
import br.com.enforcado.componente.ComponenteImagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;

public class CenarioTelaInicio extends  CCLayer{
	public CenarioTelaInicio() {
		ComponenteImagem imagemCenarioFundoTela = new ComponenteImagem(ConfiguracaoImagemCaminho.FUNDO_CENARIO);
		imagemCenarioFundoTela.setPosition(CGPoint.ccp(larguraDaCena() / 2.f, alturaDaCena() / 2.f));
		addChild(imagemCenarioFundoTela);
		
		CCSprite logo = CCSprite.sprite(ConfiguracaoImagemCaminho.LOGO);
		logo.setPosition(CGPoint.ccp( larguraDaCena() / 2.f, alturaDaCena() - 90));
		addChild(logo);
		
		addChild(new CenarioMenuInicio());
		
	}

	public CCScene criaCena(){
		
		CCScene scene = CCScene.node();
		scene.addChild(this);

		return scene;
	}

	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaInicio());
		return cena;
	}
	
}
