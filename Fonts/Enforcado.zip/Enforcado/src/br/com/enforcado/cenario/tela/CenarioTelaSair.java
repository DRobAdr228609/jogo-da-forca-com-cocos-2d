package br.com.enforcado.cenario.tela;
import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;
import br.com.enforcado.cenario.menu.CenarioMenuSair;
import br.com.enforcado.componente.ComponenteDialogoPequeno;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;

public class CenarioTelaSair extends CCLayer{
	
	/**
	 * Configura o cenario na tela de inicial do jogo
	 */
	public CenarioTelaSair() {
		addChild(new ComponenteDialogoPequeno(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_SAIR));
		addChild(new CenarioMenuSair());
		
	}
	
	/**
	 * Cria a cena e a camada do cenario configura��es
	 * @return
	 */
	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaSair());
		return cena;
	}
	
}
