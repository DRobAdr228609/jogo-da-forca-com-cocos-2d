package br.com.enforcado.cenario.tela;
import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;

import br.com.enforcado.cenario.menu.CenarioMenuOpcoesJogo;

public class CenarioTelaOpcoesJogo extends CCLayer{
	
	/**
	 * Configura o cenario na tela de inicial do jogo
	 */
	public CenarioTelaOpcoesJogo() {
		addChild(new CenarioMenuOpcoesJogo());
		
	}
	
	/**
	 * Cria a cena e a camada do cenario configura��es
	 * @return
	 */
	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaOpcoesJogo());
		return cena;
	}
	
}
