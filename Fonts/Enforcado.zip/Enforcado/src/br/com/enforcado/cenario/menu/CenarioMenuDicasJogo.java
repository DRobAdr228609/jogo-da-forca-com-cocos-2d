package br.com.enforcado.cenario.menu;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

import java.util.ArrayList;
import java.util.List;

import org.cocos2d.layers.CCColorLayer;
import org.cocos2d.layers.CCLayer;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;
import org.cocos2d.types.ccColor4B;

import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;
import br.com.enforcado.controle.ControleJogo;
import br.com.enforcado.maestro.MaestroJogo;

public class CenarioMenuDicasJogo extends CCLayer implements ContratoBotaoMenu{
	
	private CCColorLayer fundoOpaco;
	private static ComponenteBotao botaoMenuDicasJogo;
	private static ComponenteBotao botaoSetaCima;
	private static ComponenteBotao botaoSetaBaixo;
	private boolean isDicaVisivel;
	private static ComponenteBotao botaoDicas;
	private ComponenteCampoTexto rotuloTextoCabecalho;
	private List<ComponenteCampoTexto> dicas;
	private List<CCColorLayer> linhas;
	
	
	public CenarioMenuDicasJogo() {
		this.setIsTouchEnabled(true);
		criaComponentes();
		delegaComportamento();
		
		setButtonspPosition();
		scalaObjetos();
		dicionaComponentesNaTela();
		
		
	}

	
	@Override
	public void onEnter() {
		super.onEnter();
		delegaComportamento();
		isDicaVisivel = false;
		
	}

	private void delegaComportamento() {
		botaoMenuDicasJogo.setDelegate(this);
		botaoDicas.setDelegate(this);
		botaoSetaCima.setDelegate(this);
		botaoSetaBaixo.setDelegate(this);
	}

	
	private void dicionaComponentesNaTela() {
		addChild(botaoDicas);
		addChild(fundoOpaco);
		addChild(botaoMenuDicasJogo);
		addChild(rotuloTextoCabecalho);
		addChild(botaoSetaCima);
		addChild(botaoSetaBaixo);
		
		fundoOpaco.setVisible(false);
		botaoSetaBaixo.setVisible(false);
		
	}

	private void criaComponentes() {
		rotuloTextoCabecalho = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DICAS , ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccBLUE, 26);
		botaoDicas = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_DICAS , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DICAS, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18) , 0.45f );
		fundoOpaco = CCColorLayer.node(ccColor4B.ccc4(0, 0, 0, 100) , larguraDaCena(), alturaDaCena());
		botaoMenuDicasJogo = new ComponenteBotao(ConfiguracaoImagemCaminho.FUNDO_DIALOGO_PEQUENO);
		botaoSetaCima = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SETA);
		botaoSetaBaixo = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_SETA_CLICKADO);
		
		linhas = new ArrayList<CCColorLayer>();
		for (int i=0; i<=5; i++){
			CCColorLayer linha = CCColorLayer.node(ccColor4B.ccc4(190, 190, 190, 100) , 240, 1);
			linha.setPosition( resolucao(CGPoint.ccp((larguraDaCena() / 2.0f ) - 120 , ((alturaDaCena() / 2.0f)-120) - (i*20)) ) );
			linhas.add(linha);
		}
	}


	private void scalaObjetos() {
		botaoMenuDicasJogo.setScale(0.5f);
		botaoSetaCima.setScaleX(0.5f);
		botaoSetaCima.setScaleY(0.4f);
		
		botaoSetaBaixo.setScaleX(0.5f);
		botaoSetaBaixo.setScaleY(0.4f);
		
	}

	private void setButtonspPosition() {
		botaoDicas.setPosition(resolucao(CGPoint.ccp( 272 , (alturaDaCena()/2.2f)-150)));
		botaoMenuDicasJogo.setPosition( resolucao(CGPoint.ccp((larguraDaCena() / 2.0f ) - 80 , (alturaDaCena() / 2.0f) - 470) ) );
		rotuloTextoCabecalho.setPosition( resolucao(CGPoint.ccp((larguraDaCena() / 2.0f ) - 80 , (alturaDaCena() / 2.0f) - 470) ) );
		botaoSetaCima.setPosition( resolucao(CGPoint.ccp(((larguraDaCena() / 2.0f)-80 ) , ((alturaDaCena() / 2.0f)-360))));
		botaoSetaBaixo.setPosition( resolucao(CGPoint.ccp(((larguraDaCena() / 2.0f)-80 ) , ((alturaDaCena() / 2.0f) + 140))));
		
	}


	@Override
	public void clickBotao(ComponenteBotao sender) {
		
		if (sender.equals(botaoMenuDicasJogo)) {
			//onClick();
		}
		
		if (sender.equals(botaoDicas)) {
			isDicaVisivel = true;
			botaoSetaBaixo.setIsTouchEnabled(true);
			botaoSetaCima.setIsTouchEnabled(false);
			botaoDicas.setIsTouchEnabled(false);
			onClick();
		}
		
		if (sender.equals(botaoSetaCima)) {
			isDicaVisivel = true;
			botaoSetaBaixo.setIsTouchEnabled(true);
			botaoSetaCima.setIsTouchEnabled(false);
			botaoDicas.setIsTouchEnabled(false);
			onClick();
		}
		
		if (sender.equals(botaoSetaBaixo)) {
			isDicaVisivel = false;
			botaoSetaBaixo.setIsTouchEnabled(false);
			botaoSetaCima.setIsTouchEnabled(true);
			botaoDicas.setIsTouchEnabled(true);
			onClick();
			MaestroJogo.habilitaDesabilitaBotoesJogo(true);
		}
	}


	private void onClick() {
		
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(100);
		
		if (dicas == null || dicas.size()<=0){
			dicas = new ArrayList<ComponenteCampoTexto>();
			for (ComponenteCampoTexto l : ControleJogo.adicionaDica()) {
				dicas.add(l);
			}
		}
		
		if (isDicaVisivel){
			
			MaestroJogo.habilitaDesabilitaBotoesJogo(false);
			fundoOpaco.setVisible(true);
			
			botaoSetaBaixo.setVisible(true);
			botaoSetaCima.setVisible(false);
			
			for (int i = 470; i >= 250; i--) {
				botaoMenuDicasJogo.setPosition( resolucao(CGPoint.ccp((larguraDaCena() / 2.0f ) - 80 , (alturaDaCena() / 2.0f) - i) ) );
				rotuloTextoCabecalho.setPosition( resolucao(CGPoint.ccp((larguraDaCena() / 2.0f ) , ((alturaDaCena() / 2.0f) + 210) - i  )) ) ;
				botaoSetaBaixo.setPosition( resolucao(CGPoint.ccp(((larguraDaCena() / 2.0f)-80 ) , (((alturaDaCena() / 2.0f) + 110) - i))));
				
			}
			
			for (ComponenteCampoTexto l : dicas) {
				addChild(l);
			}
			
			for (CCColorLayer l : linhas) {
				addChild(l);
			}
			
		}else{
			fundoOpaco.setVisible(false);
			botaoSetaBaixo.setVisible(false);
			botaoSetaCima.setVisible(true);
			for (int i = 250; i <= 470; i++) {
				botaoMenuDicasJogo.setPosition( resolucao(CGPoint.ccp((larguraDaCena() / 2.0f ) - 80 , (alturaDaCena() / 2.0f) - i) ) );
				rotuloTextoCabecalho.setPosition( resolucao(CGPoint.ccp((larguraDaCena() / 2.0f ), ((alturaDaCena() / 2.0f)+ 210) - i) ));
				botaoSetaCima.setPosition( resolucao(CGPoint.ccp(((larguraDaCena() / 2.0f)-80 ) , (((alturaDaCena() / 2.0f) +  110) - i))));
				
			}
			
			for (ComponenteCampoTexto l : dicas) {
				removeChild(l, true);
			}
			

			for (CCColorLayer L : linhas) {
				removeChild(L, true);
			}
		}
		
	}
	
	public static void habilitaDesabilitaBotoesJogo( boolean habilitaDesabilita){
		botaoMenuDicasJogo.setIsTouchEnabled(habilitaDesabilita);
		botaoDicas.setIsTouchEnabled(habilitaDesabilita);
		botaoSetaCima.setIsTouchEnabled(habilitaDesabilita);
		botaoSetaBaixo.setIsTouchEnabled(habilitaDesabilita);
	}
}
