package br.com.enforcado.cenario.tela;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;
import br.com.enforcado.cenario.menu.CenarioMenuSobre;
import br.com.enforcado.componente.ComponenteDialogoGrande;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;

public class CenarioTelaSobre extends CCLayer{
	
	/**
	 * Configura o cenario na tela de inicial do jogo
	 */
	public CenarioTelaSobre() {
		addChild(new ComponenteDialogoGrande(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_SOBRE));
		addChild(new CenarioMenuSobre());
		
	}
	
	/**
	 * Cria a cena e a camada do cenario configura��es
	 * @return
	 */
	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaSobre());
		return cena;
	}
	
}
