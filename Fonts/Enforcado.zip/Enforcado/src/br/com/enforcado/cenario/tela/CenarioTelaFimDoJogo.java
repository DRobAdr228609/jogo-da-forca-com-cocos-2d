package br.com.enforcado.cenario.tela;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;

import br.com.enforcado.cenario.menu.CenarioMenuFimDoJogo;

public class CenarioTelaFimDoJogo extends CCLayer{
	
	public CenarioTelaFimDoJogo() {
		addChild(new CenarioMenuFimDoJogo());
	}
	
	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaFimDoJogo());
		return cena;
	}
	
}
