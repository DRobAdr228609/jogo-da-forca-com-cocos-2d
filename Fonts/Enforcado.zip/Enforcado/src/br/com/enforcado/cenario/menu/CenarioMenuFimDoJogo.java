package br.com.enforcado.cenario.menu;

import org.cocos2d.layers.CCColorLayer;
import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCSlideInBTransition;
import org.cocos2d.transitions.CCSlideInTTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;
import org.cocos2d.types.ccColor4B;

import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.cenario.tela.CenarioTelaJogo;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteCronometroJogo;
import br.com.enforcado.componente.ComponenteImagem;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

public class CenarioMenuFimDoJogo extends CCLayer implements ContratoBotaoMenu{
	
	private static CCColorLayer fundoEscuro;
	private static ComponenteImagem olhosFimJogo;
	private static ComponenteImagem logo;
	private static ComponenteBotao botaoSim;
	private static ComponenteBotao botaoNao;
	private static ComponenteCampoTexto menssagemFimJogo;
	private static ComponenteCampoTexto menssagem1;
	private static ComponenteCampoTexto menssagem2;
	
	private final float scaleX = 0.4f;
	private final float scaleY = 0.5f;
	
	public CenarioMenuFimDoJogo() {
		this.setIsTouchEnabled(true);
		ConfiguracaoIdioma.carregaTextoIdioma();
		
		criaComportamento();
		delegaComponentes();
		setPosition();
		scalaComponentes();
		dicionaComponentesNaTela();
	}

	
	public void update(float dt){
		logo.adicionaComEfeitoDeBulo(5);
		olhosFimJogo.removeComEfeitoDesvaneceEscala();
		removeChild(olhosFimJogo, true);
		olhosFimJogo.adicionaComEfeitoDeBulo(5);
		olhosFimJogo.adicionaComEfeitoDeDesvanecerParaFora();
		addChild(olhosFimJogo);
	}
	
	
	private void scalaComponentes() {
		logo.setScale(0.4f);
		olhosFimJogo.setScale(0.8f);
	}

	private void delegaComponentes() {
		botaoSim.setDelegate(this);
		botaoNao.setDelegate(this);
	}

	private void dicionaComponentesNaTela() {
		
		addChild(fundoEscuro);
		addChild(olhosFimJogo);
		addChild(logo);
		addChild(menssagemFimJogo);
		
		addChild(menssagem1);
		addChild(menssagem2);
		
		botaoSim.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoSim);
		
		botaoNao.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoNao);
		
		this.schedule("update" , 2f);
	}

	private void criaComportamento() {
		fundoEscuro = CCColorLayer.node(ccColor4B.ccc4(0, 0, 0, 300) , larguraDaCena(), alturaDaCena());
		logo = new ComponenteImagem(ConfiguracaoImagemCaminho.LOGO_APRESENTACAO);
		olhosFimJogo = new ComponenteImagem(ConfiguracaoImagemCaminho.OLHOS_FIM_JOGO);
		botaoSim = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_SIM, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
		menssagemFimJogo = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_FIM_DE_JOGO, ConfiguracaoFontCaminho.FONT_GAMIX, ccColor3B.ccRED, 30);
		
		if (ComponenteCronometroJogo.fimDoTempo){
			menssagem1 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_FIM_DE_JOGO_TEMPO_ACABOU, ConfiguracaoFontCaminho.FONT_GABE_GOOMBA, ccColor3B.ccYELLOW, 20);
			menssagem2 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_FIM_DE_JOGO_JOGAR_NOVAMENTE, ConfiguracaoFontCaminho.FONT_GABE_GOOMBA, ccColor3B.ccYELLOW, 20);
		}else{
			menssagem1 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_FIM_DE_JOGO_NAO_CERTOU_PALAVRA, ConfiguracaoFontCaminho.FONT_GABE_GOOMBA, ccColor3B.ccYELLOW, 20);
			menssagem2 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_FIM_DE_JOGO_JOGAR_NOVAMENTE, ConfiguracaoFontCaminho.FONT_GABE_GOOMBA, ccColor3B.ccYELLOW, 20);
		}
		
		botaoSim = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_SIM, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
		botaoNao = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_NAO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
	}

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setPosition() {
		logo.setPosition(CGPoint.ccp((larguraDaCena() / 2.f)-100, (alturaDaCena() / 2.f)));
		olhosFimJogo.setPosition( resolucao(CGPoint.ccp( (larguraDaCena() / 2f) -30, (alturaDaCena() /2) + 30 ) ) );	
		menssagemFimJogo.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /2) - 10)));
		
		menssagem1.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /2) - 50)));
		menssagem2.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /2) - 70)));
		
		botaoSim.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) - 60 , (alturaDaCena() /2) - 140 )));
		botaoNao.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 60 , (alturaDaCena() /2) - 140 )));
	}
	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		
		//Executa o som ao clicar no bot�o
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		if (sender.equals(botaoSim)) {
			CCDirector.sharedDirector().replaceScene( CCSlideInTTransition.transition(1f , CenarioTelaJogo.criaCenario()));
		}
		
		if (sender.equals(botaoNao)) {
			CCDirector.sharedDirector().replaceScene( CCSlideInBTransition.transition(1f , CenarioTelaInicio.criaCenario()));
		}
		
		
	}
	
	
}
