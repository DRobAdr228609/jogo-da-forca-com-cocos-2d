package br.com.enforcado.cenario.tela;

import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;
import org.cocos2d.types.CGPoint;

import br.com.enforcado.cenario.menu.CenarioMenuDicasJogo;
import br.com.enforcado.componente.ComponenteCronometroJogo;
import br.com.enforcado.componente.ComponenteImagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.controle.ControleJogo;
import br.com.enforcado.maestro.MaestroJogo;

public class CenarioTelaJogo extends CCLayer{
	
	public CenarioTelaJogo() {
		ComponenteImagem imagemFundo = new ComponenteImagem(ConfiguracaoImagemCaminho.FUNDO_CENARIO);
		imagemFundo.setPosition( resolucao(CGPoint.ccp( larguraDaCena() / 2.0f, alturaDaCena() / 2.0f ) ) );
		addChild(imagemFundo);
		
		ControleJogo jogo = new ControleJogo();
		if (ControleJogo.getDesafio().getPergunta() !=null ){
			addChild(new MaestroJogo());
			addChild(new CenarioMenuDicasJogo());
			addChild(new CenarioTelaOpcoesJogo());
			addChild(new ComponenteCronometroJogo());
		}else{
			addChild(new CenarioTelaInicio());
		}
		
	}
	
	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaJogo());
		return cena;
	}
	
}
