package br.com.enforcado.cenario.menu;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeDownTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import android.view.Gravity;
import android.widget.Toast;
import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteImagem;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.componente.ComponenteMenssagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;
import br.com.enforcado.controle.ControlePontuacao;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;


public class CenarioMenuPontuacao extends CCLayer implements ContratoBotaoMenu{
	
	private ComponenteBotao botaoZerar;
	private ComponenteBotao botaoCancelar;
	private ComponenteCampoTexto FACIL_CORRETO;
	private ComponenteCampoTexto FACIL_INCORRETO;
	private ComponenteCampoTexto MEDIO_CORRETO;
	private ComponenteCampoTexto MEDIO_INCORRETO;
	private ComponenteCampoTexto DIFICIL_CORRETO;
	private ComponenteCampoTexto DIFICIL_INCORRETO;
	private ComponenteCampoTexto TOTAL_CORRETO;
	private ComponenteCampoTexto TOTAL_INCORRETO;
	
	private ComponenteCampoTexto textoFacil;
	private ComponenteCampoTexto textoMedio;
	private ComponenteCampoTexto textoDificil;
	private ComponenteCampoTexto textoTotal;
	
	private ComponenteImagem iconeAcerto;
	private ComponenteImagem iconeErro;
	
	private final float scaleX = 0.4f;
	private final float scaleY = 0.5f;
	
	public CenarioMenuPontuacao() {
		this.setIsTouchEnabled(true);
		
		//ControlePontuacao.salvaPontuacaoTeste();
		ControlePontuacao.mostraPontuacao();
		
		criaComponentes();
		delegaComponentes();
		setPosition();
		adicionaComponentesNaTela();
		
	}

	private void adicionaComponentesNaTela() {
		textoFacil.adicionaComEfeitoDeBulo();
		addChild(textoFacil);
		
		textoMedio.adicionaComEfeitoDeBulo();
		addChild(textoMedio);
		
		textoDificil.adicionaComEfeitoDeBulo();
		addChild(textoDificil);
		
		textoTotal.adicionaComEfeitoDeBulo();
		addChild(textoTotal);
		
		//adiciona os bot�es na view
		botaoZerar.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoZerar);
		
		botaoCancelar.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoCancelar);
		
		adicionaComponentesPontuacao();
		
		iconeAcerto = new ComponenteImagem(ConfiguracaoImagemCaminho.ICONE_ACERTO);
		iconeErro = new ComponenteImagem(ConfiguracaoImagemCaminho.ICONE_ERRO);
		iconeAcerto.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 250, (alturaDaCena() / 2) - 60)));
		iconeErro.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 180, (alturaDaCena() / 2) - 60)));
		iconeAcerto.setScale(0.5f);
		iconeErro.setScale(0.5f);
		
		iconeAcerto.adicionaComEfeitoDeBulo(5);
		addChild(iconeAcerto);
		
		iconeErro.adicionaComEfeitoDeBulo(5);
		addChild(iconeErro);
		
		iconeAcerto = new ComponenteImagem(ConfiguracaoImagemCaminho.ICONE_ACERTO);
		iconeErro = new ComponenteImagem(ConfiguracaoImagemCaminho.ICONE_ERRO);
		iconeAcerto.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 250, (alturaDaCena() /2) - 100)));
		iconeErro.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 180, (alturaDaCena() / 2) - 100)));
		iconeAcerto.setScale(0.5f);
		iconeErro.setScale(0.5f);
		
		iconeAcerto.adicionaComEfeitoDeBulo(5);
		addChild(iconeAcerto);
		
		iconeErro.adicionaComEfeitoDeBulo(5);
		addChild(iconeErro);
		
		iconeAcerto = new ComponenteImagem(ConfiguracaoImagemCaminho.ICONE_ACERTO);
		iconeErro = new ComponenteImagem(ConfiguracaoImagemCaminho.ICONE_ERRO);
		iconeAcerto.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 250, (alturaDaCena() / 2) - 140)));
		iconeErro.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 180, (alturaDaCena() / 2) - 140)));
		iconeAcerto.setScale(0.5f);
		iconeErro.setScale(0.5f);
		
		iconeAcerto.adicionaComEfeitoDeBulo(5);
		addChild(iconeAcerto);
		
		iconeErro.adicionaComEfeitoDeBulo(5);
		addChild(iconeErro);
		
		iconeAcerto = new ComponenteImagem(ConfiguracaoImagemCaminho.ICONE_ACERTO);
		iconeErro = new ComponenteImagem(ConfiguracaoImagemCaminho.ICONE_ERRO);
		iconeAcerto.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 250, (alturaDaCena() / 2) - 180)));
		iconeErro.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 180, (alturaDaCena() / 2) - 180)));
		iconeAcerto.setScale(0.5f);
		iconeErro.setScale(0.5f);
		
		iconeAcerto.adicionaComEfeitoDeBulo(5);
		addChild(iconeAcerto);
		
		iconeErro.adicionaComEfeitoDeBulo(5);
		addChild(iconeErro);
	}

	private void adicionaComponentesPontuacao() {
		FACIL_CORRETO.adicionaComEfeitoDeBulo();
		addChild(FACIL_CORRETO);
		
		FACIL_INCORRETO.adicionaComEfeitoDeBulo();
		addChild(FACIL_INCORRETO);
		
		MEDIO_CORRETO.adicionaComEfeitoDeBulo();
		addChild(MEDIO_CORRETO);
		
		MEDIO_INCORRETO.adicionaComEfeitoDeBulo();
		addChild(MEDIO_INCORRETO);
		
		DIFICIL_CORRETO.adicionaComEfeitoDeBulo();
		addChild(DIFICIL_CORRETO);
		
		TOTAL_CORRETO.adicionaComEfeitoDeBulo();
		addChild(TOTAL_CORRETO);
		
		DIFICIL_INCORRETO.adicionaComEfeitoDeBulo();
		addChild(DIFICIL_INCORRETO);
		
		TOTAL_INCORRETO.adicionaComEfeitoDeBulo();
		addChild(TOTAL_INCORRETO);
	}

	private void delegaComponentes() {
		botaoZerar.setDelegate(this);
		botaoCancelar.setDelegate(this);
	}

	private void criaComponentes() {
		textoFacil = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DIFICULDADE_NIVEL_FACIL, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		textoMedio = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DIFICULDADE_NIVEL_MEDIO, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		textoDificil = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_DIFICULDADE_NIVEL_DIFICIL, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		textoTotal = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_PONTUACAO_TOTAL, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		
		botaoZerar = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_ZERAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
		botaoCancelar = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_CANCELAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
		
		
		criaComponentesPontuacao();
	}

	private void criaComponentesPontuacao() {
		FACIL_CORRETO = new ComponenteCampoTexto("" + ControlePontuacao.FACIL_CORRETO , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
		FACIL_INCORRETO = new ComponenteCampoTexto("" + ControlePontuacao.FACIL_INCORRETO , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
		MEDIO_CORRETO = new ComponenteCampoTexto("" + ControlePontuacao.MEDIO_CORRETO , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
		MEDIO_INCORRETO = new ComponenteCampoTexto("" + ControlePontuacao.MEDIO_INCORRETO , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
		DIFICIL_CORRETO = new ComponenteCampoTexto("" + ControlePontuacao.DIFICIL_CORRETO , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
		DIFICIL_INCORRETO = new ComponenteCampoTexto("" + ControlePontuacao.DIFICIL_INCORRETO , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
		TOTAL_CORRETO = new ComponenteCampoTexto("" + ControlePontuacao.TOTAL_CORRETO , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
		TOTAL_INCORRETO = new ComponenteCampoTexto("" + ControlePontuacao.TOTAL_INCORRETO , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
	}
	
	

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setPosition() {
		botaoZerar.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) - 60 , (alturaDaCena() /2) - 140 )));
		botaoCancelar.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 60 , (alturaDaCena() /2) - 140 )));
		
		textoFacil.setPosition(resolucao(CGPoint.ccp( larguraDaCena() - 250 , (alturaDaCena() /  2) + 60)));
		textoMedio.setPosition(resolucao(CGPoint.ccp( larguraDaCena() - 250 , (alturaDaCena() /  2) + 20)));
		textoDificil.setPosition(resolucao(CGPoint.ccp( larguraDaCena() - 250 , (alturaDaCena() /  2) - 20)));
		textoTotal.setPosition(resolucao(CGPoint.ccp( larguraDaCena() - 250 , (alturaDaCena() /  2) - 60)));
		
		posicionaComponentesPontuacao();
		
	}

	private void posicionaComponentesPontuacao() {
		FACIL_CORRETO.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 150, (alturaDaCena() / 2) + 60)));
		FACIL_INCORRETO.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 70, (alturaDaCena() / 2) + 60)));
		MEDIO_CORRETO.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 150, (alturaDaCena() / 2) + 20)));
		MEDIO_INCORRETO.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 70, (alturaDaCena() / 2) + 20)));
		DIFICIL_CORRETO.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 150, (alturaDaCena() / 2) - 20)));		
		DIFICIL_INCORRETO.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 70, (alturaDaCena() / 2) - 20)));
		TOTAL_CORRETO.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 150, (alturaDaCena() / 2) - 60)));
		TOTAL_INCORRETO.setPosition(resolucao(CGPoint.ccp(larguraDaCena() - 70, (alturaDaCena() / 2) - 60)));
	}
	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		if (sender.equals(botaoZerar)) {
			ControlePontuacao.redefinirPontuacao();
			ControlePontuacao.mostraPontuacao();
			
			onCliKcBotao(botaoZerar  , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_ZERAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccGREEN, 18), scaleX , scaleY));
			
			removeComponentesPontuacao();
			criaComponentesPontuacao();
			posicionaComponentesPontuacao();
			adicionaComponentesPontuacao();
			ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_ZERA_PONTUACAO ,  Gravity.BOTTOM  , Toast.LENGTH_SHORT , 1);
		}
		
		if (sender.equals(botaoCancelar)) {
			onCliKcBotao(botaoCancelar , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_CANCELAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccGREEN, 18), scaleX , scaleY));
			CCDirector.sharedDirector().replaceScene( CCFadeDownTransition.transition(0.1f , CenarioTelaInicio.criaCenario()));
			
			//falta implementar
			ComponenteMenssagem.menssagem( "As configura��es n�o foram modificadas",  Gravity.BOTTOM  , Toast.LENGTH_SHORT , 2);
		}

	}

	private void removeComponentesPontuacao() {
		removeChild(FACIL_CORRETO , true);
		removeChild(FACIL_INCORRETO, true);
		removeChild(MEDIO_CORRETO, true);
		removeChild(MEDIO_INCORRETO, true);
		removeChild(DIFICIL_CORRETO, true);
		removeChild(TOTAL_CORRETO, true);
		removeChild(DIFICIL_INCORRETO, true);
		removeChild(TOTAL_INCORRETO, true);
	}
	
	private void onCliKcBotao(ComponenteBotao botaoRemovido , ComponenteBotao novoBotao){
		novoBotao.setDelegate(this);
		novoBotao.setPosition(botaoRemovido.getPosition());
		novoBotao.setIsTouchEnabled(false);
		removeChild(botaoRemovido, true);
		addChild(novoBotao);
	}
	
}
