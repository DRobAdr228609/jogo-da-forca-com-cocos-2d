package br.com.enforcado.cenario.menu;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

public class CenarioMenuApresentacao extends CCLayer implements ContratoBotaoMenu{
	
	private ComponenteBotao botaoFundo;
	private ComponenteBotao botaoLogoApresentacao;
	private ComponenteBotao botaoEntrar;
	
	public CenarioMenuApresentacao() {
		this.setIsTouchEnabled(true);
		
		ConfiguracaoIdioma.carregaTextoIdioma();
		criaComponentes();
		delegaComponentes();
		setButtonspPosition();
		adicionaComponentesNaTela();
		
	}

	private void adicionaComponentesNaTela() {
		addChild(botaoFundo);
		
		botaoLogoApresentacao.adicionaBotaoComEfeitoDeBulo();
		addChild(botaoLogoApresentacao);
		
		botaoEntrar.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoEntrar);
		this.schedule("pulaComTempo" , 2f);
	}
	
	public void pulaComTempo(float dt){
		removeChild(botaoEntrar, true);
		botaoEntrar.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoEntrar);
	}

	private void delegaComponentes() {
		botaoFundo.setDelegate(this);
		botaoLogoApresentacao.setDelegate(this);
		botaoEntrar.setDelegate(this);
	}

	private void criaComponentes() {
		botaoFundo = new ComponenteBotao(ConfiguracaoImagemCaminho.FUNDO_CENARIO);
		botaoLogoApresentacao = new ComponenteBotao(ConfiguracaoImagemCaminho.LOGO_APRESENTACAO);
		botaoEntrar = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_APRESENTACAO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 26)  , 1f , 0.7f);
	}

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setButtonspPosition() {
		botaoFundo.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2.f, alturaDaCena() / 2.f)));
		botaoLogoApresentacao.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2.f, alturaDaCena() - 180)));
		botaoEntrar.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2.f, alturaDaCena() - 390)));
	}
	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		//Executa o som ao clicar no bot�o
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		onCliKcBotao(botaoEntrar , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_APRESENTACAO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES , ccColor3B.ccGREEN, 26) ,  1f , 0.7f));
		CCDirector.sharedDirector().replaceScene( CCFadeTransition.transition(1f , CenarioTelaInicio.criaCenario()));			
		
	}
	
	private void onCliKcBotao(ComponenteBotao botaoRemovido , ComponenteBotao novoBotao){
		novoBotao.setDelegate(this);
		novoBotao.setPosition(botaoRemovido.getPosition());
		novoBotao.setIsTouchEnabled(false);
		removeChild(botaoRemovido, true);
		addChild(novoBotao);
	}
	
}
