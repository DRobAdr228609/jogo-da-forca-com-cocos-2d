package br.com.enforcado.cenario.menu;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

import org.cocos2d.layers.CCColorLayer;
import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;
import org.cocos2d.types.ccColor4B;

import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.cenario.tela.CenarioTelaJogo;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteImagem;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;

public class CenarioMenuOpcoesJogo extends CCLayer implements ContratoBotaoMenu{
	
	private CCColorLayer linha;
	private ComponenteImagem fundoMenuOpcoes;
	private ComponenteBotao botaoMenuJogo;
	private ComponenteBotao botaoMenuJogoClickado;
	private ComponenteImagem imagemFundoMenu;
	private ComponenteBotao botaoNovaPergunta;
	private ComponenteBotao botaoMenuPrincipal;
	
	
	public CenarioMenuOpcoesJogo() {
		this.setIsTouchEnabled(true);
		criaComponentes();
		delegaComportamento();
		setButtonspPosition();
		dicionaComponentesNaTela();
		scalaObjetos();
	}

	
	@Override
	public void onEnter() {
		super.onEnter();
		delegaComportamento();
	}

	private void delegaComportamento() {
		botaoMenuJogo.setDelegate(this);
		botaoMenuJogoClickado.setDelegate(this);
		botaoNovaPergunta.setDelegate(this);
		botaoMenuPrincipal.setDelegate(this);
	}

	
	private void dicionaComponentesNaTela() {
		addChild(imagemFundoMenu);
		addChild(botaoMenuJogo);
		
	}


	private void adicionaComponentesDoMenu() {
		addChild(fundoMenuOpcoes);
		addChild(botaoNovaPergunta);
		addChild(linha);
		addChild(botaoMenuPrincipal);
	}
	
	private void removeComponentesDoMenu() {
		removeChild(fundoMenuOpcoes, true);
		removeChild(botaoNovaPergunta, true);
		removeChild(linha, true);
		removeChild(botaoMenuPrincipal, true);
	}


	private void criaComponentes() {
		fundoMenuOpcoes = new ComponenteImagem(ConfiguracaoImagemCaminho.FUNDO_MENU_OPCOES);
		botaoMenuJogo = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_MENU_JOGO);
		botaoMenuJogoClickado = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_MENU_JOGO_CLICKADO);
		imagemFundoMenu = new ComponenteImagem(ConfiguracaoImagemCaminho.FUNDO_MENU_TOPO);
		botaoNovaPergunta = new ComponenteBotao( ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_MENU_JOGO_OPCAO_NOVA_PALAVRA, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccBLACK, 20)  , 0.5f , 0);
		linha = CCColorLayer.node(ccColor4B.ccc4(175, 175, 175, 100) , 130, 1);
		botaoMenuPrincipal = new ComponenteBotao( ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_MENU_JOGO_OPCAO_MENU_PRINCIPAL, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccBLACK, 20)  , 0.5f , 0);
	}


	private void scalaObjetos() {
		fundoMenuOpcoes.setScale(0.6f);
		fundoMenuOpcoes.setScaleY(0.3f);
		
		botaoMenuJogo.setScale(0.4f);
		botaoMenuJogoClickado.setScale(0.4f);
	}

	private void setButtonspPosition() {
		fundoMenuOpcoes.setPosition(resolucao(CGPoint.ccp( ((larguraDaCena() / 2 ) + 10) , ((alturaDaCena() /2 ) - 50) )));
		
		botaoMenuJogo.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2 ) + 30  , (alturaDaCena() /2) + 73 )));
		botaoMenuJogoClickado.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2 ) + 30  , (alturaDaCena() /2) + 73 )));
		
		imagemFundoMenu.setPosition( resolucao(CGPoint.ccp( larguraDaCena() / 2, alturaDaCena() - 22 ) ) );
		
		botaoNovaPergunta.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2 ) + 75  , (alturaDaCena()/2 )  + 150 )));
		linha.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2 ) + 10  , (alturaDaCena()/2 )  + 120 )));
		botaoMenuPrincipal.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2 ) + 75  , (alturaDaCena()/2 )  + 90 )));
	}


	@Override
	public void clickBotao(ComponenteBotao sender) {
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		if (sender.equals(botaoMenuJogo)) {
				adicionaComponentesDoMenu();
				removeChild(botaoMenuJogo, true);
				addChild(botaoMenuJogoClickado);
		}
		
		if (sender.equals(botaoMenuJogoClickado)) {
			removeChild(botaoMenuJogoClickado, true);
			addChild(botaoMenuJogo);
			removeComponentesDoMenu();
		}
		
		if (sender.equals(botaoNovaPergunta)) {
			CCDirector.sharedDirector().replaceScene( CCFadeTransition.transition(1f , CenarioTelaJogo.criaCenario()));
		}
		
		if (sender.equals(botaoMenuPrincipal)) {
			CCDirector.sharedDirector().replaceScene( CCFadeTransition.transition(1f , CenarioTelaInicio.criaCenario()));
		}
		
		
	}
	
}
