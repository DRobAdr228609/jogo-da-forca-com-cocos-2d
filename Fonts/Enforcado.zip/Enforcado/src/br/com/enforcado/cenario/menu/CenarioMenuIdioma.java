package br.com.enforcado.cenario.menu;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeTransition;
import org.cocos2d.transitions.CCJumpZoomTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import android.view.Gravity;
import android.widget.Toast;
import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.componente.ComponenteMenssagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

public class CenarioMenuIdioma extends CCLayer implements ContratoBotaoMenu{
	
	private ComponenteBotao botaoPortugues;
	private ComponenteCampoTexto textoBotaoPortugues;
	
	private ComponenteBotao botaoIngles;
	private ComponenteCampoTexto textoBotaoIngles;
	
	private ComponenteBotao botaoEspanhol;
	private ComponenteCampoTexto textoBotaoEspanhol;
	
	private ComponenteBotao botaoFechar;
	private final float scaleX = 0.4f;
	private final float scaleY = 0.5f;
	
	public CenarioMenuIdioma() {
		this.setIsTouchEnabled(true);
		ConfiguracaoIdioma.carregaTextoIdioma();
		
		criaComponentes();
		delegaComponentes();
		setButtonspPosition();
		adicionaComponentesNaTela();
	}

	private void adicionaComponentesNaTela() {
		botaoPortugues.adicionaBotaoComEfeitoDeBulo();
		addChild(botaoPortugues);
		
		textoBotaoPortugues.adicionaComEfeitoDeBulo();
		addChild(textoBotaoPortugues);
		
		botaoIngles.adicionaBotaoComEfeitoDeBulo();
		addChild(botaoIngles);
		
		textoBotaoIngles.adicionaComEfeitoDeBulo();
		addChild(textoBotaoIngles);
		
		botaoEspanhol.adicionaBotaoComEfeitoDeBulo();
		addChild(botaoEspanhol);
		
		textoBotaoEspanhol.adicionaComEfeitoDeBulo();
		addChild(textoBotaoEspanhol);
		
		botaoFechar.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoFechar);
	}

	private void delegaComponentes() {
		botaoPortugues.setDelegate(this);
		botaoIngles.setDelegate(this);
		botaoEspanhol.setDelegate(this);
		botaoFechar.setDelegate(this);
	}

	private void criaComponentes() {
		botaoPortugues = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO);
		textoBotaoPortugues = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_IDIOMA_PORTUGUES, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		
		botaoIngles = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO);
		textoBotaoIngles = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_IDIOMA_INGLES, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		
		botaoEspanhol = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO);
		textoBotaoEspanhol = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_IDIOMA_ESPANHOL, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		
		if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.PT_BR)){
			botaoPortugues = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO);
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.EN_US)){
			botaoIngles = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO);
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.ES_ES)){
			botaoEspanhol = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO);
		}
		
		botaoFechar = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO  , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_FECHAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
	}

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setButtonspPosition() {
		//posi��o dos bot�es
		
		botaoPortugues.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 3 , (alturaDaCena() / 2) + 50 )));
		botaoIngles.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 3 , alturaDaCena() / 2 )));
		botaoEspanhol.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 3 , (alturaDaCena()  / 2  ) - 50 )));
		botaoFechar.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /2) - 140 )));
			
		if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.PT_BR)){
			textoBotaoPortugues.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 30 , (alturaDaCena() / 2) + 50 )));
			textoBotaoIngles.setPosition(resolucao(CGPoint.ccp((larguraDaCena() / 2) + 14, alturaDaCena() / 2)));
			textoBotaoEspanhol.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 20, (alturaDaCena() / 2) - 50 )));
			
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.EN_US)){
			
			textoBotaoPortugues.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 30 , (alturaDaCena() / 2) + 50 )));
			textoBotaoIngles.setPosition(resolucao(CGPoint.ccp((larguraDaCena() / 2) + 15, alturaDaCena() / 2)));
			textoBotaoEspanhol.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 20, (alturaDaCena() / 2) - 50 )));
			
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.ES_ES)){
			
			textoBotaoPortugues.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 30 , (alturaDaCena() / 2) + 50 )));
			textoBotaoIngles.setPosition(resolucao(CGPoint.ccp((larguraDaCena() / 2) + 14, alturaDaCena() / 2)));
			textoBotaoEspanhol.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 20, (alturaDaCena() / 2) - 50 )));
			
		}
		
	}
	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		
		//Executa o som ao clicar no bot�o
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		if (sender.equals(botaoPortugues)) {
			ConfiguracaoPreferencias.configuracaoIdioma(ConfiguracaoPreferencias.PT_BR);
			ConfiguracaoImagemCaminho.novoIdioma(ConfiguracaoPreferencias.IDIOMA_SELECIONADO);
			ConfiguracaoPreferencias.salvaPreferencias();

			onCliKcBotao(botaoPortugues , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO));
			onCliKcBotao(botaoIngles , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			onCliKcBotao(botaoEspanhol , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			
			CCDirector.sharedDirector().replaceScene( CCJumpZoomTransition.transition(1f , CenarioTelaInicio.criaCenario()));
			ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_SALVA_CONFIGURACAO_IDIOMA ,  Gravity.BOTTOM  , Toast.LENGTH_SHORT , 1);
		}
		
		if (sender.equals(botaoIngles)) {
			ConfiguracaoPreferencias.configuracaoIdioma(ConfiguracaoPreferencias.EN_US);
			ConfiguracaoImagemCaminho.novoIdioma(ConfiguracaoPreferencias.IDIOMA_SELECIONADO);
			ConfiguracaoPreferencias.salvaPreferencias();
			
			onCliKcBotao(botaoPortugues , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			onCliKcBotao(botaoIngles , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO));
			onCliKcBotao(botaoEspanhol , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			
			CCDirector.sharedDirector().replaceScene( CCJumpZoomTransition.transition(1f , CenarioTelaInicio.criaCenario()));
			ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_SALVA_CONFIGURACAO_IDIOMA ,  Gravity.BOTTOM  , Toast.LENGTH_SHORT  , 1);
		}
		
		if (sender.equals(botaoEspanhol)) {
			ConfiguracaoPreferencias.configuracaoIdioma("es/");
			ConfiguracaoImagemCaminho.novoIdioma(ConfiguracaoPreferencias.IDIOMA_SELECIONADO);
			ConfiguracaoPreferencias.salvaPreferencias();
			
			onCliKcBotao(botaoPortugues , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			onCliKcBotao(botaoIngles , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_DESATIVADO));
			onCliKcBotao(botaoEspanhol , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_CHECKBOX_ATIVADO));
			
			CCDirector.sharedDirector().replaceScene( CCJumpZoomTransition.transition(1f , CenarioTelaInicio.criaCenario()));
			ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_SALVA_CONFIGURACAO_IDIOMA ,  Gravity.BOTTOM  , Toast.LENGTH_SHORT ,  1);
		}
		
		if (sender.equals(botaoFechar)) {
			onCliKcBotao(botaoFechar  , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_FECHAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccGREEN, 18)  , scaleX , scaleY));
			CCDirector.sharedDirector().replaceScene( CCFadeTransition.transition(0.1f , CenarioTelaInicio.criaCenario()));
			
			//falta implementar
			ComponenteMenssagem.menssagem("As configura��es n�o foram alteradas" ,  Gravity.BOTTOM  , Toast.LENGTH_SHORT ,  2);
		}
		
	}
	
	private void onCliKcBotao(ComponenteBotao botaoRemovido , ComponenteBotao novoBotao){
		novoBotao.setDelegate(this);
		novoBotao.setPosition(botaoRemovido.getPosition());
		novoBotao.setIsTouchEnabled(false);
		removeChild(botaoRemovido, true);
		addChild(novoBotao);
	}

}
