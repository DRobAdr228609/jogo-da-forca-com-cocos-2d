package br.com.enforcado.cenario.menu;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeDownTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteImagem;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

public class CenarioMenuSobre extends CCLayer implements ContratoBotaoMenu{
	
	private ComponenteImagem logo;
	private ComponenteCampoTexto textoVrsaoJogo;
	private ComponenteCampoTexto textoDesenvolvidoPor;
	private ComponenteCampoTexto textoDesenvolvedor1;
	private ComponenteCampoTexto textoDesenvolvedor2;
	private ComponenteCampoTexto textoDesenvolvedor3;
	
	private ComponenteBotao botaoFechar;
	private final float scaleX = 0.4f;
	private final float scaleY = 0.5f;
	
	public CenarioMenuSobre() {
		this.setIsTouchEnabled(true);
		ConfiguracaoIdioma.carregaTextoIdioma();
		
		criaComponentes();
		botaoFechar.setDelegate(this);
		setPosicao();
		dicionaComponentesNaTela();
	}

	private void dicionaComponentesNaTela() {
		
		logo.adicionaComEfeitoDeBulo(5);
		addChild(logo);
		
		textoVrsaoJogo.adicionaComEfeitoDeBulo();
		addChild(textoVrsaoJogo);
		
		textoDesenvolvidoPor.adicionaComEfeitoDeBulo();
		addChild(textoDesenvolvidoPor);
		
		textoDesenvolvedor1.adicionaComEfeitoDeBulo();
		addChild(textoDesenvolvedor1);
		
		textoDesenvolvedor2.adicionaComEfeitoDeBulo();
		addChild(textoDesenvolvedor2);
		
		textoDesenvolvedor3.adicionaComEfeitoDeBulo();
		addChild(textoDesenvolvedor3);
		
		botaoFechar.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoFechar);
	}

	private void criaComponentes() {
		logo = new ComponenteImagem(ConfiguracaoImagemCaminho.LOGO);
				
		textoVrsaoJogo = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_SOBRE_VERSAO_JOGO, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 16);
		textoDesenvolvidoPor = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_SOBRE_DESENVOLVIDO_POR, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 20);
		
		textoDesenvolvedor1 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_SOBRE_NOME_DESENVOLVEDOR1, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 16);
		textoDesenvolvedor2 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_SOBRE_NOME_DESENVOLVEDOR2, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 16);
		textoDesenvolvedor3 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_SOBRE_NOME_DESENVOLVEDOR3, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 16);
		
		botaoFechar = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_FECHAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
	}

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setPosicao() {
		//posi��o dos bot�es
		logo.setScale(0.4f);
		logo.setPosition(CGPoint.ccp((larguraDaCena() / 2.f) -100, (alturaDaCena() / 2.f) -80));
		textoVrsaoJogo.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /  2)  + 15)));
		textoDesenvolvidoPor.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /  2) - 20 )));
		textoDesenvolvedor1.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /  2) - 40 )));
		textoDesenvolvedor2.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /  2) - 60 )));
		textoDesenvolvedor3.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /  2) - 80 )));
		
		botaoFechar.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /2) - 140 )));
			
			
		
	}
	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		
		//Executa o som ao clicar no bot�o
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		
		if (sender.equals(botaoFechar)) {
			onCliKcBotao(botaoFechar , new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_FECHAR, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccGREEN, 18), scaleX , scaleY));
			CCDirector.sharedDirector().replaceScene( CCFadeDownTransition.transition(0.1f , CenarioTelaInicio.criaCenario()));
		}
		
		
	}
	
	private void onCliKcBotao(ComponenteBotao botaoRemovido , ComponenteBotao novoBotao){
		novoBotao.setDelegate(this);
		novoBotao.setPosition(botaoRemovido.getPosition());
		novoBotao.setIsTouchEnabled(false);
		removeChild(botaoRemovido, true);
		addChild(novoBotao);
	}

}
