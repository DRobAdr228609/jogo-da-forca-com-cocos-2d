package br.com.enforcado.cenario.tela;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.layers.CCScene;
import br.com.enforcado.cenario.menu.CenarioMenuDificuldade;
import br.com.enforcado.componente.ComponenteDialogoGrande;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;

public class CenarioTelaDificuldade extends CCLayer{
	public CenarioTelaDificuldade() {
		addChild(new ComponenteDialogoGrande(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_DIFICULDADE));
		addChild(new CenarioMenuDificuldade());
		
	}
	
	/**
	 * Cria a cena e a camada do cenario configura��es
	 * @return
	 */
	public static CCScene criaCenario(){
		CCScene cena = CCScene.node();
		cena.addChild(new CenarioTelaDificuldade());
		return cena;
	}
	
}
