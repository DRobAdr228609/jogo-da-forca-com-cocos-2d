package br.com.enforcado.cenario.menu;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeDownTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

public class CenarioMenuSair extends CCLayer implements ContratoBotaoMenu{
	
	private ComponenteBotao botaoSim;
	private ComponenteBotao botaoNao;
	private ComponenteCampoTexto textoConfirmacao1;
	private ComponenteCampoTexto textoConfirmacao2;
	
	private final float scaleX = 0.4f;
	private final float scaleY = 0.5f;
	
	public CenarioMenuSair() {
		this.setIsTouchEnabled(true);
		ConfiguracaoIdioma.carregaTextoIdioma();
		criaComponentes();
		// coloca bot�es na posi��o correta
		setPosition();
		adicionaComponentesNaTela();
	}

	private void adicionaComponentesNaTela() {
		textoConfirmacao1.adicionaComEfeitoDeBulo();
		addChild(textoConfirmacao1);
		
		textoConfirmacao2.adicionaComEfeitoDeBulo();
		addChild(textoConfirmacao2);
		
		botaoSim.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoSim);
		
		botaoNao.adicionaBotaoETextoComEfeitoDeBulo();
		addChild(botaoNao);
	}

	private void criaComponentes() {
		textoConfirmacao1 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_CONFIRMACAO_SAIR1, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		textoConfirmacao2 = new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_CONFIRMACAO_SAIR2, ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR, ccColor3B.ccBLACK, 18);
		
		botaoSim = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_SIM, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
		botaoNao = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_NAO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, 18), scaleX , scaleY);
		
		delegaComportamento();
	}

	private void delegaComportamento() {
		botaoSim.setDelegate(this);
		botaoNao.setDelegate(this);
	}

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setPosition() {
		textoConfirmacao1.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /  2))));
		textoConfirmacao2.setPosition(resolucao(CGPoint.ccp( larguraDaCena() / 2 , (alturaDaCena() /  2) - 20)));
		
		botaoSim.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) - 60 , (alturaDaCena() /2) - 90 )));
		botaoNao.setPosition(resolucao(CGPoint.ccp( (larguraDaCena() / 2) + 60 , (alturaDaCena() /2) - 90 )));
		
	}
	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		
		//Executa o som ao clicar no bot�o
		ConfiguracaoSom.somClickBotao();
		ConfiguracaoPreferencias.vibrarCelular(30);
		
		
		if (sender.equals(botaoSim)) {
			onCliKcBotao(botaoSim ,  new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_SIM, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccGREEN, 18), scaleX , scaleY));
			ConfiguracaoPreferencias.salvaPreferencias();
			System.exit(0);
		}
		
		if (sender.equals(botaoNao)) {
			onCliKcBotao(botaoNao ,  new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_GENERICO_CLICKADO , new ComponenteCampoTexto(ConfiguracaoIdioma.TEXTO_BOTAO_CABECALHO_NAO, ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccGREEN, 18), scaleX , scaleY));
			CCDirector.sharedDirector().replaceScene( CCFadeDownTransition.transition(0.1f , CenarioTelaInicio.criaCenario()));
		}
		
		
	}

	
	private void onCliKcBotao(ComponenteBotao botaoRemovido , ComponenteBotao novoBotao){
		novoBotao.setDelegate(this);
		novoBotao.setPosition(botaoRemovido.getPosition());
		novoBotao.setIsTouchEnabled(false);
		removeChild(botaoRemovido, true);
		addChild(novoBotao);
	}
}
