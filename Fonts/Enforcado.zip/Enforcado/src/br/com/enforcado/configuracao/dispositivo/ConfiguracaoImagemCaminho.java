package br.com.enforcado.configuracao.dispositivo;

public class ConfiguracaoImagemCaminho {

	/**
	 * Constantes de caminhos das imagens do projeto
	 */
	
	public static String idioma;
	
	public static String FUNDO_CENARIO = "fundo/fundo-cenario.png";
	public static String FUNDO_DIALOGO_GRANDE = "fundo/fundo-dialogo-grande.png";
	public static String FUNDO_DIALOGO_PEQUENO = "fundo/fundo-dialogo-pequeno.png";
	public static String FUNDO_MENU_TOPO = "fundo/fundo-menu-topo.png";
	public static String FUNDO_PERGUNTA = "fundo/fundo-pergunta.png";
	public static String FUNDO_MENU_OPCOES = "fundo/fundo-menu-opcoes.png";
	
	
	public static String OLHOS_FIM_JOGO = "olhos-fim-jogo.png";
	
	
	//Caminho das imagens de fundo dos cenarios do jogo
	public static String LOGO = "logo/logo.png";
	public static String LOGO_APRESENTACAO = "logo/logo-splash.png";
	
	public static String BOTAO_SETA = "botao/botao-seta.png";
	public static String BOTAO_SETA_CLICKADO = "botao/botao-seta-clickado.png";
	
	public static String BOTAO_DICAS = "botao/botao-dicas.png";
	public static String BOTAO_DICAS_CLICKADO = "botao/botao-dicas-clickado.png";
	public static String BOTAO_GENERICO= "botao/botao-generico.png";
	public static String BOTAO_GENERICO_CLICKADO = "botao/botao-generico-clickado.png";
	
	public static String BOTAO_SOM_ATIVO = "botao/botao-som.png";
	public static String BOTAO_SOM_ATIVO_CLICKADO = "botao/botao-som-clickado.png";
	public static String BOTAO_SOM_DESATIVADO = "botao/botao-som-desativado.png";
	public static String BOTAO_SOM_DESATIVADO_CLICKADO = "botao/botao-som-desativado-clickado.png";
	public static String BOTAO_IDIOMA = "botao/botao-idioma.png";
	public static String BOTAO_IDIOMA_CLICKADO = "botao/botao-idioma-clickado.png";
	public static String BOTAO_SOBRE = "botao/botao-sobre.png";
	public static String BOTAO_SOBRE_CLICKADO = "botao/botao-sobre-clickado.png";
	public static String BOTAO_SAIR = "botao/botao-sair.png";
	public static String BOTAO_SAIR_CLICKADO = "botao/botao-sair-clickado.png";
	
	public static String BOTAO_CHECKBOX_ATIVADO = "botao/botao-checkbox-ativado.png";
	public static String BOTAO_CHECKBOX_DESATIVADO = "botao/botao-checkbox-desativado.png";
	
	public static String BOTAO_LETRA = "botao/botao-letra.png";
	
	public static String BOTAO_MENU_JOGO = "botao/botao-menu-jogo.png";
	public static String BOTAO_MENU_JOGO_CLICKADO = "botao/botao-menu-jogo-clickado.png";
	
	public static String AMOSTRA = "amostra.png";
	
	public static String BONECO_FORCA0 = "boneco/forca0.png";
	public static String BONECO_FORCA1 = "boneco/forca1.png";
	public static String BONECO_FORCA2 = "boneco/forca2.png";
	public static String BONECO_FORCA3 = "boneco/forca3.png";
	public static String BONECO_FORCA4 = "boneco/forca4.png";
	public static String BONECO_FORCA5 = "boneco/forca5.png";
	public static String BONECO_FORCA6 = "boneco/forca6.png";
	
	public static String BOTAO_JOGADA_CORRETA = "botao/botao-correto.png";
	public static String BOTAO_JOGADA_INCORRETA = "botao/botao-incorreto.png";
	
	public static String ICONE_ACERTO = "icone/icone-acertos.png";
	public static String ICONE_ERRO = "icone/icone-erros.png";
	
	public static void novoIdioma(String novoIdioma){
		idioma  = novoIdioma;
	}
	
}
