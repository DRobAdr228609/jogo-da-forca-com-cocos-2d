package br.com.enforcado.configuracao.dispositivo;

public class ConfiguracaoFontCaminho {

	public static String FONT_HAND_DRAWN_SHAPES = "font/Hand_Drawn_Shapes_0.ttf";
	public static String FONT_ROBOTO_REGULAR = "font/Roboto-Regular.ttf";
	
	public static String FONT_GABE_GOOMBA = "font/Gabe_Goomba.ttf";
	public static String FONT_GAMIX = "font/Gamix.ttf";
	public static String FONT_DIGITTAL_DS = "font/Digital_DS.TTF";
	
	
}
