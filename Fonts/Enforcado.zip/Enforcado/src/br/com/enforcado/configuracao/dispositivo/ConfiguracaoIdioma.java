package br.com.enforcado.configuracao.dispositivo;

import br.com.enforcado.R;

public class ConfiguracaoIdioma {
	
	public static String TEXTO_BOTAO_APRESENTACAO;
	public static String TEXTO_BOTAO_NOVO_JOGO;
	public static String TEXTO_BOTAO_DIFICULDADE;
	public static String TEXTO_BOTAO_PONTUACAO;
	public static String TEXTO_BOTAO_CABECALHO_FECHAR;
	
	public static String TEXTO_BOTAO_CABECALHO_IDIOMA;
	public static String TEXTO_BOTAO_CABECALHO_PONTUACAO;
	public static String TEXTO_BOTAO_CABECALHO_DIFICULDADE;
	
	public static String TEXTO_BOTAO_IDIOMA_PORTUGUES;
	public static String TEXTO_BOTAO_IDIOMA_INGLES;
	public static String TEXTO_BOTAO_IDIOMA_ESPANHOL;
	
	public static String TEXTO_BOTAO_DIFICULDADE_NIVEL_FACIL;
	public static String TEXTO_BOTAO_DIFICULDADE_NIVEL_MEDIO;
	public static String TEXTO_BOTAO_DIFICULDADE_NIVEL_DIFICIL;
	
	public static String TEXTO_BOTAO_CABECALHO_SOBRE;
	public static String TEXTO_BOTAO_CABECALHO_SAIR;
	public static String TEXTO_BOTAO_CABECALHO_SIM;
	public static String TEXTO_BOTAO_CABECALHO_NAO;
	
	public static String TEXTO_CONFIRMACAO_SAIR1;
	public static String TEXTO_CONFIRMACAO_SAIR2;
	
	public static String TEXTO_SOBRE_VERSAO_JOGO;
	public static String TEXTO_SOBRE_DESENVOLVIDO_POR;
	public static String TEXTO_SOBRE_NOME_DESENVOLVEDOR1;
	public static String TEXTO_SOBRE_NOME_DESENVOLVEDOR2;
	public static String TEXTO_SOBRE_NOME_DESENVOLVEDOR3;
	
	public static String TEXTO_BOTAO_CABECALHO_ZERAR;
	public static String TEXTO_BOTAO_CABECALHO_CANCELAR;
	
	public static String TEXTO_PONTUACAO_TOTAL;
	
	public static String TEXTO_BOTAO_DICAS;
	
	public static String TEXTO_FIM_DE_JOGO;
	public static String TEXTO_FIM_DE_JOGO_TEMPO_ACABOU;
	public static String TEXTO_FIM_DE_JOGO_JOGAR_NOVAMENTE;
	public static String TEXTO_FIM_DE_JOGO_NAO_CERTOU_PALAVRA;
	
	public static String TEXTO_OPCAO_VOLTAR_DESABILITADO;
	
	public static String TEXTO_MENU_JOGO_OPCAO_NOVA_PALAVRA;
	public static String TEXTO_MENU_JOGO_OPCAO_MENU_PRINCIPAL;
	public static String TEXTO_SALVA_CONFIGURACAO_SOM;
	public static String TEXTO_SALVA_CONFIGURACAO_IDIOMA;
	public static String TEXTO_SALVA_CONFIGURACAO_NIVEL_DIFICULDADE;
	
	public static String TEXTO_ZERA_PONTUACAO;
	
	public static String TEXTO_DICA_JOGADA_MEDIA;
	public static String TEXTO_DICA_JOGADA_FINAL;
	
	public static String TEXTO_PASSAGEM_NIVEL_DIFICULDADE;
	public static String TEXTO_ULTIMA_PERGUNTA;
	
	
	public static void carregaTextoIdioma() {
		
		TEXTO_SOBRE_NOME_DESENVOLVEDOR1 = "Davi Roberto";
		TEXTO_SOBRE_NOME_DESENVOLVEDOR2 = "Marcelo Ramalho";
		TEXTO_SOBRE_NOME_DESENVOLVEDOR3 = "Hayd�e Toscano";
		
		if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.PT_BR)){
			TEXTO_BOTAO_APRESENTACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_apresentacao);
			TEXTO_BOTAO_NOVO_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_novo_jogo);
			TEXTO_BOTAO_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_dificuldade);
			TEXTO_BOTAO_PONTUACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_pontuacao);
			TEXTO_BOTAO_PONTUACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_pontuacao);
			
			TEXTO_BOTAO_CABECALHO_IDIOMA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_cabecalho_idioma);
			TEXTO_BOTAO_CABECALHO_PONTUACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_cabecalho_pontuacao);
			TEXTO_BOTAO_CABECALHO_FECHAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_fechar);
			
			TEXTO_BOTAO_IDIOMA_PORTUGUES = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_idioma_portugue);
			TEXTO_BOTAO_IDIOMA_INGLES = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_idioma_ingles);
			TEXTO_BOTAO_IDIOMA_ESPANHOL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_idioma_espanhol);
			
			TEXTO_BOTAO_CABECALHO_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_cabecalho_dificuldade);
			
			TEXTO_BOTAO_DIFICULDADE_NIVEL_FACIL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_dificuldade_nivel_facil);
			TEXTO_BOTAO_DIFICULDADE_NIVEL_MEDIO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_dificuldade_nivel_medio);
			TEXTO_BOTAO_DIFICULDADE_NIVEL_DIFICIL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_dificuldade_nivel_dificil);
			
			TEXTO_BOTAO_CABECALHO_SOBRE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_cabecalho_sobre);
			TEXTO_BOTAO_CABECALHO_SAIR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_cabecalho_sair);
			
			TEXTO_BOTAO_CABECALHO_SIM = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_sim);
			TEXTO_BOTAO_CABECALHO_NAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_nao);
			
			TEXTO_CONFIRMACAO_SAIR1 = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_confirmacao_sair1);
			TEXTO_CONFIRMACAO_SAIR2 = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_confirmacao_sair2);
			
			TEXTO_SOBRE_VERSAO_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_sobre_verso_jogo);
			TEXTO_SOBRE_DESENVOLVIDO_POR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_sobre_desenvolvido_por);
			
			TEXTO_BOTAO_CABECALHO_ZERAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_zerar);
			TEXTO_BOTAO_CABECALHO_CANCELAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_cancelar);
			
			TEXTO_PONTUACAO_TOTAL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_pontuacao_total);
			
			TEXTO_BOTAO_DICAS = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_botao_dicas);
			
			TEXTO_FIM_DE_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_fim_do_jogo);
			TEXTO_FIM_DE_JOGO_TEMPO_ACABOU = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_fim_do_jogo_tempo_acabou);
			TEXTO_FIM_DE_JOGO_JOGAR_NOVAMENTE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_fim_do_jogo_jogar_novamente);
			TEXTO_FIM_DE_JOGO_NAO_CERTOU_PALAVRA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_fim_do_jogo_nao_acertou_palavra);
			
			TEXTO_OPCAO_VOLTAR_DESABILITADO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_opcao_voltar_desabilitado);
			
			
			TEXTO_MENU_JOGO_OPCAO_NOVA_PALAVRA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_menu_jogo_opcao_nova_palavra);
			TEXTO_MENU_JOGO_OPCAO_MENU_PRINCIPAL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_menu_jogo_opcao_menu_principal);
			TEXTO_SALVA_CONFIGURACAO_SOM = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_salva_configuracao_som);
			TEXTO_SALVA_CONFIGURACAO_IDIOMA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_salva_configuracao_idioma);
			TEXTO_SALVA_CONFIGURACAO_NIVEL_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_salva_configuracao_nivel_dificuldade);
			TEXTO_ZERA_PONTUACAO  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_zerar_pontuacao);
			
			TEXTO_DICA_JOGADA_MEDIA  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_dica_jogada_media);
			TEXTO_DICA_JOGADA_FINAL  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_dica_jogada_final);
			
			TEXTO_PASSAGEM_NIVEL_DIFICULDADE =  ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_passagem_nivel_dificuldade);
			TEXTO_ULTIMA_PERGUNTA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.ptbr_texto_ultima_pergunta);
			
			
			
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.EN_US)){
			
			TEXTO_BOTAO_APRESENTACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_apresentacao);
			TEXTO_BOTAO_NOVO_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_novo_jogo);
			TEXTO_BOTAO_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_dificuldade);
			TEXTO_BOTAO_PONTUACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_pontuacao);
			TEXTO_BOTAO_CABECALHO_FECHAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_fechar);
			
			TEXTO_BOTAO_CABECALHO_IDIOMA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_cabecalho_idioma);
			TEXTO_BOTAO_CABECALHO_PONTUACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_cabecalho_pontuacao);
			
			TEXTO_BOTAO_IDIOMA_PORTUGUES = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_idioma_portugue);
			TEXTO_BOTAO_IDIOMA_INGLES = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_idioma_ingles);
			TEXTO_BOTAO_IDIOMA_ESPANHOL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_idioma_espanhol);
			
			TEXTO_BOTAO_CABECALHO_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_cabecalho_dificuldade);
			
			TEXTO_BOTAO_DIFICULDADE_NIVEL_FACIL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_dificuldade_nivel_facil);
			TEXTO_BOTAO_DIFICULDADE_NIVEL_MEDIO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_dificuldade_nivel_medio);
			TEXTO_BOTAO_DIFICULDADE_NIVEL_DIFICIL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_dificuldade_nivel_dificil);
			
			TEXTO_BOTAO_CABECALHO_SOBRE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_cabecalho_sobre);
			TEXTO_BOTAO_CABECALHO_SAIR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_cabecalho_sair);
			
			TEXTO_BOTAO_CABECALHO_SIM = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_sim);
			TEXTO_BOTAO_CABECALHO_NAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_nao);
			
			TEXTO_CONFIRMACAO_SAIR1 = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_confirmacao_sair1);
			TEXTO_CONFIRMACAO_SAIR2 = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_confirmacao_sair2);
			
			TEXTO_SOBRE_VERSAO_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_sobre_verso_jogo);
			TEXTO_SOBRE_DESENVOLVIDO_POR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_sobre_desenvolvido_por);
			
			TEXTO_BOTAO_CABECALHO_ZERAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_zerar);
			TEXTO_BOTAO_CABECALHO_CANCELAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_cancelar);
			
			TEXTO_PONTUACAO_TOTAL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_pontuacao_total);
			
			TEXTO_BOTAO_DICAS = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_botao_dicas);
			
			TEXTO_FIM_DE_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_fim_do_jogo);
			TEXTO_FIM_DE_JOGO_TEMPO_ACABOU = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_fim_do_jogo_tempo_acabou);
			TEXTO_FIM_DE_JOGO_JOGAR_NOVAMENTE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_fim_do_jogo_jogar_novamente);
			TEXTO_FIM_DE_JOGO_NAO_CERTOU_PALAVRA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_fim_do_jogo_nao_acertou_palavra);
			
			TEXTO_OPCAO_VOLTAR_DESABILITADO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_opcao_voltar_desabilitado);
			
			TEXTO_MENU_JOGO_OPCAO_NOVA_PALAVRA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_menu_jogo_opcao_nova_palavra);
			TEXTO_MENU_JOGO_OPCAO_MENU_PRINCIPAL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_menu_jogo_opcao_menu_principal);
			TEXTO_SALVA_CONFIGURACAO_SOM = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_salva_configuracao_som);
			TEXTO_SALVA_CONFIGURACAO_IDIOMA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_salva_configuracao_idioma);
			TEXTO_SALVA_CONFIGURACAO_NIVEL_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_salva_configuracao_nivel_dificuldade);
			TEXTO_ZERA_PONTUACAO  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_zerar_pontuacao);
			
			TEXTO_DICA_JOGADA_MEDIA  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_dica_jogada_media);
			TEXTO_DICA_JOGADA_FINAL  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_dica_jogada_final);
			
			TEXTO_PASSAGEM_NIVEL_DIFICULDADE =  ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_passagem_nivel_dificuldade);
			TEXTO_ULTIMA_PERGUNTA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.enus_texto_ultima_pergunta);
			
			
			
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.ES_ES)){
			TEXTO_BOTAO_APRESENTACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_apresentacao);
			TEXTO_BOTAO_NOVO_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_novo_jogo);
			TEXTO_BOTAO_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_dificuldade);
			TEXTO_BOTAO_PONTUACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_pontuacao);
			TEXTO_BOTAO_CABECALHO_FECHAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_fechar);
			
			TEXTO_BOTAO_CABECALHO_IDIOMA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_cabecalho_idioma);
			TEXTO_BOTAO_CABECALHO_PONTUACAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_cabecalho_pontuacao);
			
			TEXTO_BOTAO_IDIOMA_PORTUGUES = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_idioma_portugue);
			TEXTO_BOTAO_IDIOMA_INGLES = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_idioma_ingles);
			TEXTO_BOTAO_IDIOMA_ESPANHOL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_idioma_espanhol);
			
			TEXTO_BOTAO_CABECALHO_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_cabecalho_dificuldade);
			
			TEXTO_BOTAO_DIFICULDADE_NIVEL_FACIL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_dificuldade_nivel_facil);
			TEXTO_BOTAO_DIFICULDADE_NIVEL_MEDIO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_dificuldade_nivel_medio);
			TEXTO_BOTAO_DIFICULDADE_NIVEL_DIFICIL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_dificuldade_nivel_dificil);
			
			TEXTO_BOTAO_CABECALHO_SOBRE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_cabecalho_sobre);
			TEXTO_BOTAO_CABECALHO_SAIR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_cabecalho_sair);
			
			TEXTO_BOTAO_CABECALHO_SIM = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_sim);
			TEXTO_BOTAO_CABECALHO_NAO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_nao);
			
			TEXTO_CONFIRMACAO_SAIR1 = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_confirmacao_sair1);
			TEXTO_CONFIRMACAO_SAIR2 = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_confirmacao_sair2);
			
			TEXTO_SOBRE_VERSAO_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_sobre_verso_jogo);
			TEXTO_SOBRE_DESENVOLVIDO_POR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_sobre_desenvolvido_por);
			
			TEXTO_BOTAO_CABECALHO_ZERAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_zerar);
			TEXTO_BOTAO_CABECALHO_CANCELAR = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_cancelar);
			
			TEXTO_PONTUACAO_TOTAL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_pontuacao_total);
			
			TEXTO_BOTAO_DICAS = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_botao_dicas);
			
			TEXTO_FIM_DE_JOGO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_fim_do_jogo);
			TEXTO_FIM_DE_JOGO_TEMPO_ACABOU = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_fim_do_jogo_tempo_acabou);
			TEXTO_FIM_DE_JOGO_JOGAR_NOVAMENTE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_fim_do_jogo_jogar_novamente);
			TEXTO_FIM_DE_JOGO_NAO_CERTOU_PALAVRA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_fim_do_jogo_nao_acertou_palavra);
			
			TEXTO_OPCAO_VOLTAR_DESABILITADO = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_opcao_voltar_desabilitado);
			
			TEXTO_MENU_JOGO_OPCAO_NOVA_PALAVRA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_menu_jogo_opcao_nova_palavra);
			TEXTO_MENU_JOGO_OPCAO_MENU_PRINCIPAL = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_menu_jogo_opcao_menu_principal);
			TEXTO_SALVA_CONFIGURACAO_SOM = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_salva_configuracao_som);
			TEXTO_SALVA_CONFIGURACAO_IDIOMA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_salva_configuracao_idioma);
			TEXTO_SALVA_CONFIGURACAO_NIVEL_DIFICULDADE = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_salva_configuracao_nivel_dificuldade);
			TEXTO_ZERA_PONTUACAO  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_zerar_pontuacao);
			
			TEXTO_DICA_JOGADA_MEDIA  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_dica_jogada_media);
			TEXTO_DICA_JOGADA_FINAL  = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_dica_jogada_final);
			
			TEXTO_PASSAGEM_NIVEL_DIFICULDADE =  ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_passagem_nivel_dificuldade);
			TEXTO_ULTIMA_PERGUNTA = ConfiguracaoPreferencias.CONTEXTO.getString(R.string.eses_texto_ultima_pergunta);
			
		}
	}
	
	
	
}
