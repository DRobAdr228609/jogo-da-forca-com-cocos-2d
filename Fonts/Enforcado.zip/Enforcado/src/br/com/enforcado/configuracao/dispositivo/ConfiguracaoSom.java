package br.com.enforcado.configuracao.dispositivo;

import org.cocos2d.nodes.CCDirector;
import org.cocos2d.sound.SoundEngine;

import android.widget.Toast;
import br.com.enforcado.R;

public class ConfiguracaoSom {
	/**
	 * Adiciona e configura sons do jogo
	 */
	public static void somClickBotao(){
		if(ConfiguracaoPreferencias.SOM){
			SoundEngine.sharedEngine().playEffect(
					CCDirector.sharedDirector().getActivity(), R.raw.click);
		}
	}
	
	public static void somTema(){
		if(ConfiguracaoPreferencias.SOM){
			SoundEngine.sharedEngine().playSound(
					CCDirector.sharedDirector().getActivity(), R.raw.tema, true);
			
		}else{
			SoundEngine.sharedEngine().pauseSound();
		}
		
	}
	
	public static void paraSomJogo(){
		SoundEngine.sharedEngine().pauseSound();
	}
	
	public static void somJogadaCorreta(){
		if (ConfiguracaoPreferencias.SOM){
			SoundEngine.sharedEngine().playEffect(CCDirector.sharedDirector().getActivity(), R.raw.correto);
		}
	}
	
	public static void somJogadaIncorreta(){
		if (ConfiguracaoPreferencias.SOM){
			SoundEngine.sharedEngine().playEffect(CCDirector.sharedDirector().getActivity(), R.raw.incorreto);
		}
	}
	
	
}
