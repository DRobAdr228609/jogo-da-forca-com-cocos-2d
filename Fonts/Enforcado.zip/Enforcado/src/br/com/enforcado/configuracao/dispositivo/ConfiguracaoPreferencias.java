package br.com.enforcado.configuracao.dispositivo;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Vibrator;

public class ConfiguracaoPreferencias {

		//OP��ES DE IDIOMA	
		public static String PT_BR = "pt/";
		public static String EN_US = "en/";
		public static String ES_ES = "es/";
		
		//OP��ES DE NIVEIS DE DIFICULDADE
		public static int FACIL = 1;
		public static int MEDIO = 2;
		public static int DIFICIL = 3;
		
		public static int PTBR = 1;
		public static int ENUS = 2;
		public static int ESES = 3;
		
		public static int STATUS_DESAFIO_ABERTO = 1;
		public static int STATUS_DESAFIO_FECHADO = 2;
		
		public static String IDIOMA_SELECIONADO;
		public static boolean SOM;
		public static int NIVEL_DIFICULDADE_SELECIONADO;
		public static Context CONTEXTO;
		
		public static void configuracaoIdioma(String idioma){
			IDIOMA_SELECIONADO = idioma;
		}
		
		public static void configuracaoSom(boolean som){
			SOM = som;
		}
		
		public static void configuracaoNivelDificuldade(int nivelDificuldade){
			NIVEL_DIFICULDADE_SELECIONADO = nivelDificuldade;
		}

		public static void delegaContexto(Context contexto){
			CONTEXTO = contexto;
		}
		
		public static void salvaPreferencias(){
			SharedPreferences configuracoes = ConfiguracaoPreferencias.CONTEXTO.getSharedPreferences("preferencias" , Context.MODE_PRIVATE);
			SharedPreferences.Editor  editor = configuracoes.edit();
			editor.putString("idioma", ConfiguracaoPreferencias.IDIOMA_SELECIONADO);
			editor.putBoolean("som", ConfiguracaoPreferencias.SOM);
			editor.putInt("dificuldade", ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO);
			editor.commit();
			
		}
		
		public static void vibrarCelular( long milliseconds){
	        Vibrator rr = (Vibrator) ConfiguracaoPreferencias.CONTEXTO.getSystemService(Context.VIBRATOR_SERVICE);
	        rr.vibrate(milliseconds); 
	    }

}
