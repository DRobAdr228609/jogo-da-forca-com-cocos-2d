package br.com.enforcado.maestro;

import java.util.ArrayList;
import java.util.List;

import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCFadeTransition;
import org.cocos2d.transitions.CCSlideInBTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import br.com.enforcado.cenario.tela.CenarioTelaFimDoJogo;
import br.com.enforcado.cenario.tela.CenarioTelaInicio;
import br.com.enforcado.cenario.tela.CenarioTelaJogo;
import br.com.enforcado.componente.ComponenteBotao;
import br.com.enforcado.componente.ComponenteImagem;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.componente.ComponenteLetraImagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.contrato.ContratoBotaoMenu;
import br.com.enforcado.controle.ControleJogo;
import br.com.enforcado.controle.ControlePontuacao;

//importa o metodo diretamente da classe
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

public class MaestroJogo extends CCLayer implements ContratoBotaoMenu{
	
	private static ComponenteBotao botaoA;
	private static ComponenteBotao botaoB;
	private static ComponenteBotao botaoC;
	private static ComponenteBotao botaoD;
	private static ComponenteBotao botaoE;
	private static ComponenteBotao botaoF;
	private static ComponenteBotao botaoG;
	
	private static ComponenteBotao botaoH;
	private static ComponenteBotao botaoI;
	private static ComponenteBotao botaoJ;
	private static ComponenteBotao botaoK;
	private static ComponenteBotao botaoL;
	private static ComponenteBotao botaoM;
	private static ComponenteBotao botaoN;
	
	private static ComponenteBotao botaoO;
	private static ComponenteBotao botaoP;
	private static ComponenteBotao botaoQ;
	private static ComponenteBotao botaoR;
	private static ComponenteBotao botaoS;
	private static ComponenteBotao botaoT;
	private static ComponenteBotao botaoU;
	
	private static ComponenteBotao botaoV;
	private static ComponenteBotao botaoW;
	private static ComponenteBotao botaoX;
	private static ComponenteBotao botaoY;
	private static ComponenteBotao botaoZ;
	
	private ControleJogo jogo;
	private List<ComponenteCampoTexto> letrasVisiveis;
	private ComponenteImagem bonecoForca;
	
	private final float scalaS = 0.45f;
	private final int tamanhoFont = 20;
	private int pulos = 2;
	
	public MaestroJogo() {
		jogo = new ControleJogo();
		this.setIsTouchEnabled(true);
		
		criaComponentes();
		delegaComportamento();
		
		
		setButtonspPosition();
		adicionaComponentesNaTela();
		//CCDirector.sharedDirector().replaceScene( CCSlideInBTransition.transition(1.0f , CenarioTelaInicio.criaCenario()));
		//addChild(new CenarioTelaInicio().criaCena());
		
	}
	

	private void adicionaComponentesNaTela() {
		addChild(botaoA);
		addChild(botaoB);
		addChild(botaoC);
		addChild(botaoD);
		addChild(botaoE);
		addChild(botaoF);
		addChild(botaoG);
		
		addChild(botaoH);
		addChild(botaoI);
		addChild(botaoJ);
		addChild(botaoK);
		addChild(botaoL);
		addChild(botaoM);
		addChild(botaoN);
		
		addChild(botaoO);
		addChild(botaoP);
		addChild(botaoQ);
		addChild(botaoR);
		addChild(botaoS);
		addChild(botaoT);
		addChild(botaoU);
		
		addChild(botaoV);
		addChild(botaoW);
		addChild(botaoX);
		addChild(botaoY);
		addChild(botaoZ);
		
		addChild(jogo.fundoPergunta());
		
		for (ComponenteCampoTexto p : jogo.adicionaPergunta()) {
			addChild(p);
		}
		
		bonecoForca = jogo.adicionaBonecoForca();
		addChild(bonecoForca);
		
		if(jogo.getAmostras()!=null){
			for (ComponenteLetraImagem a: jogo.getAmostras()){
				addChild(a);
			}
		}
		
	}

	private void delegaComportamento() {
		botaoA.setDelegate(this);
		botaoB.setDelegate(this);
		botaoC.setDelegate(this);
		botaoD.setDelegate(this);
		botaoE.setDelegate(this);
		botaoF.setDelegate(this);
		botaoG.setDelegate(this);
		
		botaoH.setDelegate(this);
		botaoI.setDelegate(this);
		botaoJ.setDelegate(this);
		botaoK.setDelegate(this);
		botaoL.setDelegate(this);
		botaoM.setDelegate(this);
		botaoN.setDelegate(this);
		
		botaoO.setDelegate(this);
		botaoP.setDelegate(this);
		botaoQ.setDelegate(this);
		botaoR.setDelegate(this);
		botaoS.setDelegate(this);
		botaoT.setDelegate(this);
		botaoU.setDelegate(this);
		
		botaoV.setDelegate(this);
		botaoW.setDelegate(this);
		botaoX.setDelegate(this);
		botaoY.setDelegate(this);
		botaoZ.setDelegate(this);
	}

	private void criaComponentes() {
		botaoA = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("A", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoB = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA, new ComponenteCampoTexto("B", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoC = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA, new ComponenteCampoTexto("C", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoD = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA, new ComponenteCampoTexto("D", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoE = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA, new ComponenteCampoTexto("E", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoF = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA, new ComponenteCampoTexto("F", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoG = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA, new ComponenteCampoTexto("G", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		
		botaoH = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("H", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoI = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("I", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoJ = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("J", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoK = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("K", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoL = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("L", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoM = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("M", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoN = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("N", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		
		botaoO = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("O", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoP = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("P", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoQ = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("Q", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoR = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("R", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoS = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("S", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoT = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("T", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoU = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("U", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		
		botaoV = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("V", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoW = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("W", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoX = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("X", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoY = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("Y", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
		botaoZ = new ComponenteBotao(ConfiguracaoImagemCaminho.BOTAO_LETRA , new ComponenteCampoTexto("Z", ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES, ccColor3B.ccWHITE, tamanhoFont) , scalaS);
	}

	/**
	 * Configura a posi��o dos bot�es
	 */
	private void setButtonspPosition() {
		//posi��o dos bot�es
		
		botaoA.setPosition(resolucao(CGPoint.ccp( 25 , alturaDaCena()/2.5f)));
		botaoB.setPosition(resolucao(CGPoint.ccp( 70 , alturaDaCena()/2.5f)));
		botaoC.setPosition(resolucao(CGPoint.ccp( 115 , alturaDaCena()/2.5f)));
		botaoD.setPosition(resolucao(CGPoint.ccp( 160 , alturaDaCena()/2.5f)));
		botaoE.setPosition(resolucao(CGPoint.ccp( 205 , alturaDaCena()/2.5f)));
		botaoF.setPosition(resolucao(CGPoint.ccp( 250 , alturaDaCena()/2.5f)));
		botaoG.setPosition(resolucao(CGPoint.ccp( 295 , alturaDaCena()/2.5f)));
		botaoH.setPosition(resolucao(CGPoint.ccp( 25 , (alturaDaCena()/2.4f)-50)));
		botaoI.setPosition(resolucao(CGPoint.ccp( 70 , (alturaDaCena()/2.4f)-50)));
		botaoJ.setPosition(resolucao(CGPoint.ccp( 115 , (alturaDaCena()/2.4f)-50)));
		botaoK.setPosition(resolucao(CGPoint.ccp( 160 , (alturaDaCena()/2.4f)-50)));
		botaoL.setPosition(resolucao(CGPoint.ccp( 205 , (alturaDaCena()/2.4f)-50)));
		botaoM.setPosition(resolucao(CGPoint.ccp( 250 , (alturaDaCena()/2.4f)-50)));
		botaoN.setPosition(resolucao(CGPoint.ccp( 295 , (alturaDaCena()/2.4f)-50)));
		botaoO.setPosition(resolucao(CGPoint.ccp( 25 , (alturaDaCena()/2.3f )-100)));
		botaoP.setPosition(resolucao(CGPoint.ccp( 70 , (alturaDaCena()/2.3f )-100)));
		botaoQ.setPosition(resolucao(CGPoint.ccp( 115 , (alturaDaCena()/2.3f )-100)));
		botaoR.setPosition(resolucao(CGPoint.ccp( 160 , (alturaDaCena()/2.3f )-100)));
		botaoS.setPosition(resolucao(CGPoint.ccp( 205 , (alturaDaCena()/2.3f )-100)));
		botaoT.setPosition(resolucao(CGPoint.ccp( 250 , (alturaDaCena()/2.3f )-100)));
		botaoU.setPosition(resolucao(CGPoint.ccp( 295 , (alturaDaCena()/2.3f )-100)));
		botaoV.setPosition(resolucao(CGPoint.ccp( 25 , (alturaDaCena()/2.2f)-150)));
		botaoW.setPosition(resolucao(CGPoint.ccp( 70 , (alturaDaCena()/2.2f)-150)));
		botaoX.setPosition(resolucao(CGPoint.ccp( 115 , (alturaDaCena()/2.2f)-150)));
		botaoY.setPosition(resolucao(CGPoint.ccp( 160 , (alturaDaCena()/2.2f)-150)));
		botaoZ.setPosition(resolucao(CGPoint.ccp( 205 , (alturaDaCena()/2.2f)-150)));
		
	}
	
	
	/**
 	* Adiciona os eventos de click do menu
 	*/
	@Override
	public void clickBotao(ComponenteBotao sender) {
		//Executa o som ao clicar no bot�o
		//ConfiguracaoSom.somClickBotao();
		letrasVisiveis = new ArrayList<ComponenteCampoTexto>();
		
		
		if (sender.equals(botaoA)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("a"));
			atulizaJogada(letrasVisiveis, botaoA);
		}
		
		if (sender.equals(botaoB)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("b"));
			atulizaJogada(letrasVisiveis, botaoB);
		}
		
		if (sender.equals(botaoC)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("c"));
			atulizaJogada(letrasVisiveis, botaoC);
		}
		
		if (sender.equals(botaoD)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("d"));
			atulizaJogada(letrasVisiveis, botaoD);
		}
		
		if (sender.equals(botaoE)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("e"));
			atulizaJogada(letrasVisiveis, botaoE);
			
		}
		
		if (sender.equals(botaoF)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("f"));
			atulizaJogada(letrasVisiveis, botaoF);
		}
		
		if (sender.equals(botaoG)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("g"));
			atulizaJogada(letrasVisiveis, botaoG);
		}
		
		if (sender.equals(botaoH)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("h"));
			atulizaJogada(letrasVisiveis, botaoH);
		}
		
		if (sender.equals(botaoI)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("i"));
			atulizaJogada(letrasVisiveis, botaoI);
		}
		
		if (sender.equals(botaoJ)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("j"));
			atulizaJogada(letrasVisiveis, botaoJ);
		}
		
		if (sender.equals(botaoK)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("k"));
			atulizaJogada(letrasVisiveis, botaoK);
		}
		
		if (sender.equals(botaoL)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("l"));
			atulizaJogada(letrasVisiveis, botaoL);
		}
		
		if (sender.equals(botaoM)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("m"));
			atulizaJogada(letrasVisiveis, botaoM);
		}
		
		if (sender.equals(botaoN)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("n"));
			atulizaJogada(letrasVisiveis, botaoN);
		}
		
		if (sender.equals(botaoO)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("o"));
			atulizaJogada(letrasVisiveis, botaoO);
		}
		
		if (sender.equals(botaoP)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("p"));
			atulizaJogada(letrasVisiveis, botaoP);
		}
		
		if (sender.equals(botaoQ)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("q"));
			atulizaJogada(letrasVisiveis, botaoQ);
		}
		
		if (sender.equals(botaoR)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("r"));
			atulizaJogada(letrasVisiveis, botaoR);
		}
		
		if (sender.equals(botaoS)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("s"));
			atulizaJogada(letrasVisiveis, botaoS);
		}
		
		if (sender.equals(botaoT)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("t"));
			atulizaJogada(letrasVisiveis, botaoT);
		}
		
		if (sender.equals(botaoU)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("u"));
			atulizaJogada(letrasVisiveis, botaoU);
		}
		
		if (sender.equals(botaoV)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("v"));
			atulizaJogada(letrasVisiveis, botaoV);
		}
		
		if (sender.equals(botaoW)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("w"));
			atulizaJogada(letrasVisiveis, botaoW);
		}
		
		if (sender.equals(botaoX)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("x"));
			atulizaJogada(letrasVisiveis, botaoX);
		}
		
		if (sender.equals(botaoY)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("y"));
			atulizaJogada(letrasVisiveis, botaoY);
		}
		
		if (sender.equals(botaoZ)) {
			letrasVisiveis.addAll(jogo.adicionaLetraNaTela("z"));
			atulizaJogada(letrasVisiveis, botaoZ);
		}
		
	}
	
	
	public void atulizaJogada(List<ComponenteCampoTexto> letrasVisiveis , ComponenteBotao botao){
		
		if(ControleJogo.isJogando){
			botao.removeComEfeitoDesvaneceEscala();
			if(letrasVisiveis.size() > 0){
				ConfiguracaoSom.somJogadaCorreta();
				ConfiguracaoPreferencias.vibrarCelular(50);
				
				for (ComponenteCampoTexto c : letrasVisiveis) {
					c.adicionaComEfeitoDeBulo();
					addChild(c);
				}
			
				jogo.setOpcaoCorreta(jogo.getOpcaoCorreta() + letrasVisiveis.size());
				if (ControleJogo.getDesafio().getPergunta().length() == jogo.getOpcaoCorreta()){
					jogo.updateDesafio();
				}
			
				ComponenteLetraImagem ok = new ComponenteLetraImagem(ConfiguracaoImagemCaminho.BOTAO_JOGADA_CORRETA);
				ok.setPosition(resolucao(CGPoint.ccp( botao.getPosition().x , botao.getPosition().y)));
				ok.adicionaComEfeitoDeFadeESacala();
				addChild(ok);
				
				if(jogo.getLetras().size()<=0){
					jogo.palavraCorretaFimDeJogo();
					ControleJogo.verificaJogoRodando(false);
					ControlePontuacao.adicionaPontuacaoPalavraCorreta();
					CCDirector.sharedDirector().replaceScene( CCFadeTransition.transition(4f , CenarioTelaJogo.criaCenario()));
				}
			
			}else{
				
				ConfiguracaoSom.somJogadaIncorreta();
				ConfiguracaoPreferencias.vibrarCelular(200);
			
				jogo.setOpcaoErrada(jogo.getOpcaoErrada() + 1 );
				ComponenteLetraImagem exlamacao = new ComponenteLetraImagem(ConfiguracaoImagemCaminho.BOTAO_JOGADA_INCORRETA);
				exlamacao.adicionaComEfeitoDeFadeESacala();
				exlamacao.setPosition(resolucao(CGPoint.ccp( botao.getPosition().x , botao.getPosition().y)));
				addChild(exlamacao);
			
				bonecoForca.removeComEfeitoDesvaneceEscala();
				removeChild(bonecoForca, true);
			
				bonecoForca = jogo.adicionaBonecoForca();
				bonecoForca.adicionaComEfeitoDeBulo(pulos);
				addChild(bonecoForca);
				++pulos;
				
				if (!ControleJogo.isJogando){
					letrasVisiveis.addAll(ControleJogo.adicionaLetraNaTelaAposFimDoJogo());
					for (ComponenteCampoTexto c : letrasVisiveis) {
						c.adicionaComEfeitoDeBulo();
						addChild(c);
					}
					
					ControlePontuacao.adicionaPontuacaoPalavraIncorreta();
					CCDirector.sharedDirector().replaceScene( CCFadeTransition.transition(4f , CenarioTelaFimDoJogo.criaCenario()));
				}
			}
			
			removeChild(botao, true);
			
		}
	}
	
	
	public static void habilitaDesabilitaBotoesJogo( boolean habilitaDesabilita){
		botaoA.setIsTouchEnabled(habilitaDesabilita);
		botaoB.setIsTouchEnabled(habilitaDesabilita);
		botaoC.setIsTouchEnabled(habilitaDesabilita);
		botaoD.setIsTouchEnabled(habilitaDesabilita);
		botaoE.setIsTouchEnabled(habilitaDesabilita);
		botaoF.setIsTouchEnabled(habilitaDesabilita);
		botaoG.setIsTouchEnabled(habilitaDesabilita);
		
		botaoH.setIsTouchEnabled(habilitaDesabilita);
		botaoI.setIsTouchEnabled(habilitaDesabilita);
		botaoJ.setIsTouchEnabled(habilitaDesabilita);
		botaoK.setIsTouchEnabled(habilitaDesabilita);
		botaoL.setIsTouchEnabled(habilitaDesabilita);
		botaoM.setIsTouchEnabled(habilitaDesabilita);
		botaoN.setIsTouchEnabled(habilitaDesabilita);
		
		botaoO.setIsTouchEnabled(habilitaDesabilita);
		botaoP.setIsTouchEnabled(habilitaDesabilita);
		botaoQ.setIsTouchEnabled(habilitaDesabilita);
		botaoR.setIsTouchEnabled(habilitaDesabilita);
		botaoS.setIsTouchEnabled(habilitaDesabilita);
		botaoT.setIsTouchEnabled(habilitaDesabilita);
		botaoU.setIsTouchEnabled(habilitaDesabilita);
		
		botaoV.setIsTouchEnabled(habilitaDesabilita);
		botaoW.setIsTouchEnabled(habilitaDesabilita);
		botaoX.setIsTouchEnabled(habilitaDesabilita);
		botaoY.setIsTouchEnabled(habilitaDesabilita);
		botaoZ.setIsTouchEnabled(habilitaDesabilita);
	}
	
}
