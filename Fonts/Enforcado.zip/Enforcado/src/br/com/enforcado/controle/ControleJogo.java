package br.com.enforcado.controle;

import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.resolucao;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


import org.cocos2d.layers.CCLayer;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.transitions.CCSlideInBTransition;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.ccColor3B;

import android.annotation.SuppressLint;
import android.view.Gravity;
import android.widget.Toast;
import br.com.enforcado.cenario.tela.CenarioTelaJogo;
import br.com.enforcado.componente.ComponenteImagem;
import br.com.enforcado.componente.ComponenteCampoTexto;
import br.com.enforcado.componente.ComponenteLetraImagem;
import br.com.enforcado.componente.ComponenteMenssagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoFontCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import br.com.enforcado.dao.DesafioDao;
import br.com.enforcado.mb.Desafio;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.larguraDaCena;
import static br.com.enforcado.configuracao.dispositivo.ConfiguracaoDispositivo.alturaDaCena;

public class ControleJogo extends CCLayer{
	private static List<ComponenteLetraImagem> letras;
	private List<ComponenteLetraImagem> amostras;
	private DesafioDao dao =  new DesafioDao(ConfiguracaoPreferencias.CONTEXTO);
	private int opcaoCorreta = 0;
	private int opcaoErrada = 0;
	private static Desafio desafio;
	public static boolean isJogando;
	
	public ControleJogo() {
		desafio = new Desafio();
		
		if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.PT_BR)){
			
			desafio = dao.buscaDesafio( ConfiguracaoPreferencias.PTBR , ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO, ConfiguracaoPreferencias.STATUS_DESAFIO_ABERTO);
			verifcaDesafio();	
				
				
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.EN_US)){
			
			desafio = dao.buscaDesafio( ConfiguracaoPreferencias.ENUS , ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO, ConfiguracaoPreferencias.STATUS_DESAFIO_ABERTO);
			verifcaDesafio();	
			
		}else if (ConfiguracaoPreferencias.IDIOMA_SELECIONADO.equals(ConfiguracaoPreferencias.ES_ES)){
			
			desafio = dao.buscaDesafio( ConfiguracaoPreferencias.ESES , ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO, ConfiguracaoPreferencias.STATUS_DESAFIO_ABERTO);
			verifcaDesafio();	
		}
		
		if (desafio.getResposta() != null){
			aicionaLetras();
		}
		
		isJogando = true;
	}
	
	
	
	public void verifcaDesafio(){
		if (desafio.getId() == null){
			
			if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.FACIL){
				ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_PASSAGEM_NIVEL_DIFICULDADE , Gravity.BOTTOM , Toast.LENGTH_SHORT  , 2);
				ConfiguracaoPreferencias.configuracaoNivelDificuldade(ConfiguracaoPreferencias.MEDIO);
				ConfiguracaoPreferencias.salvaPreferencias();
				CCDirector.sharedDirector().replaceScene( CCSlideInBTransition.transition(1.0f , CenarioTelaJogo.criaCenario()));
				
			}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.MEDIO){
				ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_PASSAGEM_NIVEL_DIFICULDADE , Gravity.BOTTOM , Toast.LENGTH_SHORT  , 2);
				ConfiguracaoPreferencias.configuracaoNivelDificuldade(ConfiguracaoPreferencias.DIFICIL);
				ConfiguracaoPreferencias.salvaPreferencias();
				CCDirector.sharedDirector().replaceScene( CCSlideInBTransition.transition(1.0f , CenarioTelaJogo.criaCenario()));
			}else{
				ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_ULTIMA_PERGUNTA , Gravity.BOTTOM , Toast.LENGTH_SHORT  , 3);
				//CCDirector.sharedDirector().replaceScene( CCSlideInBTransition.transition(1.0f , CenarioTelaInicio.criaCenario()));
			}
		}
	}
	
	public void aicionaLetras(){
		letras= new ArrayList<ComponenteLetraImagem>();
		amostras = new ArrayList<ComponenteLetraImagem>();
		
		//verificar o tamanho da resposta e come�ar o posicionamento conforme o tamanho para centralizar na tela
		float x = 25;
	    float y = 215;
	    
	    	if (desafio.getResposta().length()==9){
	    		x = x  * 2;
	    	}else if (desafio.getResposta().length()==8){
	    		x = x + 30;
	    	}else if (desafio.getResposta().length()==7){
	    		x = x + 50;
	    	}else if (desafio.getResposta().length()==6){
	    		x = x + 60;
	    	}else if (desafio.getResposta().length()==5){
	    		x = x + 70;
	    	}else if (desafio.getResposta().length()==4){
	    		x = x + 80;
	    	}
	    
		for(int i=0; i<desafio.getResposta().length(); i++){
			
			ComponenteLetraImagem letra = new ComponenteLetraImagem( ConfiguracaoImagemCaminho.BOTAO_LETRA);
			ComponenteLetraImagem amostra = new ComponenteLetraImagem( ConfiguracaoImagemCaminho.AMOSTRA);
			
			letra.setLetra( "" + desafio.getResposta().charAt(i));
			
			letra.setPosition(resolucao(CGPoint.ccp( (larguraDaCena()-larguraDaCena()) + x, alturaDaCena()-y)));
			amostra.setPosition(resolucao(CGPoint.ccp( (larguraDaCena()-larguraDaCena()) + x, alturaDaCena()-y)));
			
			letras.add(letra);
			amostras.add(amostra);
			x +=30;
		}
		
	    }
	
	
	public void updateDesafio(){
		dao.updateDesafio(desafio);
	}
	
	@SuppressLint("DefaultLocale")
	public List<ComponenteCampoTexto> adicionaLetraNaTela(String letra){
		
		List<ComponenteCampoTexto> lestrasVisiveis = new ArrayList<ComponenteCampoTexto>();
		List<ComponenteLetraImagem> lestrasASeremRemovidas = new ArrayList<ComponenteLetraImagem>();
		
		if (letras!=null){
			for (ComponenteLetraImagem l: letras) {
				if (l.getLetra().equals(letra)){
					ComponenteCampoTexto novaLetra =  new ComponenteCampoTexto(letra.toUpperCase() , ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES ,  ccColor3B.ccGREEN  , 26);
					novaLetra.setPosition(l.getPosition());
					lestrasVisiveis.add(novaLetra);
					lestrasASeremRemovidas.add(l);
				}
			}
		
			letras.removeAll(lestrasASeremRemovidas);
		}	
		return lestrasVisiveis;
	}
	
	@SuppressLint("DefaultLocale")
	public static List<ComponenteCampoTexto> adicionaLetraNaTelaAposFimDoJogo(){
		
		List<ComponenteCampoTexto> lestrasVisiveis = new ArrayList<ComponenteCampoTexto>();
			for (ComponenteLetraImagem l: letras) {
					ComponenteCampoTexto novaLetra =  new ComponenteCampoTexto(l.getLetra().toUpperCase() , ConfiguracaoFontCaminho.FONT_HAND_DRAWN_SHAPES ,  ccColor3B.ccRED , 26);
					novaLetra.setPosition(l.getPosition());
					lestrasVisiveis.add(novaLetra);
			}
		
		return lestrasVisiveis;
	}
	
	
	public ComponenteImagem fundoPergunta(){
		ComponenteImagem imagemFundo = new ComponenteImagem(ConfiguracaoImagemCaminho.FUNDO_PERGUNTA);
		imagemFundo.setPosition( resolucao(CGPoint.ccp( (larguraDaCena() / 2f) -85, alturaDaCena() / 2f) ) );
		imagemFundo.setScaleY(0.5f);
		imagemFundo.setScaleX(0.46f);
		return imagemFundo;
	}
	
	public ComponenteImagem adicionaBonecoForca(){
		ComponenteImagem bonecoForca = null;
		
		if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.FACIL){
			
			switch (opcaoErrada) {
			case 1:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA1);
				break;
			case 2:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA2);
				ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_DICA_JOGADA_MEDIA ,Gravity.CENTER_HORIZONTAL , Toast.LENGTH_SHORT , 1);
				break;
			case 3:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA3);
				break;
			case 4:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA4);
				break;
			case 5:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA5);
				ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_DICA_JOGADA_FINAL ,Gravity.CENTER_HORIZONTAL , Toast.LENGTH_SHORT , 2);
				break;
			case 6:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA6);
				isJogando = false;
				break;
			default:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA0);
				break;
			}
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.MEDIO){
			switch (opcaoErrada) {
			case 1:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA2);
				break;
			case 2:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA3);
				break;
			case 3:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA5);
				ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_DICA_JOGADA_FINAL ,Gravity.CENTER_HORIZONTAL , Toast.LENGTH_SHORT , 2);
				break;
			case 4:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA6);
				isJogando = false;
				break;
			default:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA0);
				break;
			}
		}else{
			switch (opcaoErrada) {
			case 1:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA5);
				break;
			case 2:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA6);
				isJogando = false;
				break;
			default:
				bonecoForca = novoBonecoForca(ConfiguracaoImagemCaminho.BONECO_FORCA0);
				break;
			}
		}
		
		return bonecoForca;
	}
	
	public ComponenteImagem novoBonecoForca(String imagem){
		ComponenteImagem bonecoForca = new ComponenteImagem(imagem);
		bonecoForca.setPosition( resolucao(CGPoint.ccp( (larguraDaCena() / 2.0f) + 103, alturaDaCena()-120) ) );
		return bonecoForca;
	}
	
	public List<ComponenteCampoTexto> adicionaPergunta(){
		List<ComponenteCampoTexto> perguntas = new ArrayList<ComponenteCampoTexto>();
		
		if(desafio.getPergunta() != null){
			String auxPerguntas[] = desafio.getPergunta().split(Pattern.quote(" "));  
			String auxPergunta= "";
			
			int y=0;
			if (auxPerguntas.length>=60){
				y=10;
			}
		
		for (int i = 0; i < auxPerguntas.length; i++) {
			
			String auxTexto = auxPergunta + " " + auxPerguntas[i];
			if ( auxTexto.length() <= 20 ){
				
				auxPergunta = auxTexto; 
				
			}else{
				
				ComponenteCampoTexto p = new ComponenteCampoTexto(auxPergunta , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
				p.setPosition(resolucao(CGPoint.ccp( (larguraDaCena()/2f) - 40 , (alturaDaCena()-90)-y)));
				perguntas.add(p);
				y+=20;
				
				auxPergunta = "";
				i--;
			}
			
		}
		
		//verifica se ainda sobrou palavras
		if (auxPergunta.length()>0){
			ComponenteCampoTexto p = new ComponenteCampoTexto(auxPergunta , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
			p.setPosition(resolucao(CGPoint.ccp( (larguraDaCena()/2f) - 40 , (alturaDaCena()-90)-y)));
			perguntas.add(p);
			auxPergunta = "";
		}
		}	
		return perguntas;
	}
	
	public static List<ComponenteCampoTexto> adicionaDica(){
		List<ComponenteCampoTexto> dicas = new ArrayList<ComponenteCampoTexto>();
		
		if (desafio.getDica() != null){
			String auxDicas[] = desafio.getDica().split(Pattern.quote(" "));  
			String auxDica= "";
			int y=250;
		
			if (desafio.getDica().length()>40){
				for (int i = 0; i < auxDicas.length; i++) {
					String auxTexto = auxDica + " " + auxDicas[i];
					if ( auxTexto.length() <= 30 ){
				
						auxDica = auxTexto; 
				
					}else{
						ComponenteCampoTexto p = new ComponenteCampoTexto(auxDica , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
						p.setPosition(resolucao(CGPoint.ccp( (larguraDaCena()/2f), (alturaDaCena()-100)-y)));
						dicas.add(p);
						y+=20;
				
						auxDica = "";
						i--;
					}
			
				}
				
				if (auxDica.length()>0){
					ComponenteCampoTexto p = new ComponenteCampoTexto(auxDica , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
					p.setPosition(resolucao(CGPoint.ccp( (larguraDaCena()/2f) , (alturaDaCena()-100)-y)));
					dicas.add(p);
					auxDica = "";
				}
			}else{
				
				ComponenteCampoTexto p = new ComponenteCampoTexto(desafio.getDica() , ConfiguracaoFontCaminho.FONT_ROBOTO_REGULAR ,  ccColor3B.ccBLACK  , 18);
				p.setPosition(resolucao(CGPoint.ccp( (larguraDaCena()/2f) , (alturaDaCena()-100)-y)));
				dicas.add(p);
			}
		}
		return dicas;
	}
	
	public void palavraCorretaFimDeJogo(){
		dao.updateDesafio(desafio);
	}
	
	public static void verificaJogoRodando(boolean jogando){
		isJogando = jogando;
	}
	
	public List<ComponenteLetraImagem> getLetras() {
		return letras;
	}

	public List<ComponenteLetraImagem> getAmostras() {
		return amostras;
	}

	public void setAmostras(List<ComponenteLetraImagem> amostras) {
		this.amostras = amostras;
	}

	public int getOpcaoCorreta() {
		return opcaoCorreta;
	}

	public void setOpcaoCorreta(int opcaoCorreta) {
		this.opcaoCorreta = opcaoCorreta;
	}

	public int getOpcaoErrada() {
		return opcaoErrada;
	}

	public void setOpcaoErrada(int opcaoErrada) {
		this.opcaoErrada = opcaoErrada;
	}

	public static Desafio getDesafio() {
		return desafio;
	}

	public static void setDesafio(Desafio desafio) {
		ControleJogo.desafio = desafio;
	}

	
}
