package br.com.enforcado.controle;

import android.content.Context;
import android.content.SharedPreferences;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;

public class ControlePontuacao {
	private static SharedPreferences pontuacao = ConfiguracaoPreferencias.CONTEXTO.getSharedPreferences("pontuacao" , Context.MODE_PRIVATE);
	
	public static int FACIL_CORRETO;
	public static int FACIL_INCORRETO;
	public static int MEDIO_CORRETO;
	public static int MEDIO_INCORRETO;
	public static int DIFICIL_CORRETO;
	public static int DIFICIL_INCORRETO;
	public static int TOTAL_CORRETO;
	public static int TOTAL_INCORRETO;
	
	
	//Retirar esse metodo quando terminar  os testes
	public static void salvaPontuacaoTeste(){
		SharedPreferences.Editor  editor = pontuacao.edit();
		editor.putInt("FACIL_CORRETO", 22);
		editor.putInt("FACIL_INCORRETO", 12);
		editor.putInt("MEDIO_CORRETO", 15);
		editor.putInt("MEDIO_INCORRETO", 8);
		editor.putInt("DIFICIL_CORRETO", 5);
		editor.putInt("DIFICIL_INCORRETO", 2);
		editor.putInt("TOTAL_CORRETO", 42);
		editor.putInt("TOTAL_INCORRETO", 22);
		
		editor.commit();
		
	}
	

	public static void salvaPontuacao(){
		SharedPreferences.Editor  editor = pontuacao.edit();
		editor.putInt("FACIL_CORRETO", FACIL_CORRETO);
		editor.putInt("FACIL_INCORRETO", FACIL_INCORRETO);
		editor.putInt("MEDIO_CORRETO", MEDIO_CORRETO);
		editor.putInt("MEDIO_INCORRETO", MEDIO_INCORRETO);
		editor.putInt("DIFICIL_CORRETO", DIFICIL_CORRETO);
		editor.putInt("DIFICIL_INCORRETO", DIFICIL_INCORRETO);
		editor.putInt("TOTAL_CORRETO", TOTAL_CORRETO);
		editor.putInt("TOTAL_INCORRETO", TOTAL_INCORRETO);
		
		editor.commit();
		
	}
	
	public static void mostraPontuacao(){
		ControlePontuacao.FACIL_CORRETO = pontuacao.getInt("FACIL_CORRETO", 0);
		ControlePontuacao.FACIL_INCORRETO = pontuacao.getInt("FACIL_INCORRETO", 0);
		ControlePontuacao.MEDIO_CORRETO = pontuacao.getInt("MEDIO_CORRETO", 0);
		ControlePontuacao.MEDIO_INCORRETO = pontuacao.getInt("MEDIO_INCORRETO", 0);
		ControlePontuacao.DIFICIL_CORRETO = pontuacao.getInt("DIFICIL_CORRETO", 0);
		ControlePontuacao.DIFICIL_INCORRETO = pontuacao.getInt("DIFICIL_INCORRETO", 0);
		ControlePontuacao.TOTAL_CORRETO = pontuacao.getInt("TOTAL_CORRETO", 0);
		ControlePontuacao.TOTAL_INCORRETO = pontuacao.getInt("TOTAL_INCORRETO", 0);
		
		
	}
	
	public static void redefinirPontuacao(){
		ControlePontuacao.FACIL_CORRETO = 0;
		ControlePontuacao.FACIL_INCORRETO = 0;
		ControlePontuacao.MEDIO_CORRETO = 0;
		ControlePontuacao.MEDIO_INCORRETO = 0;
		ControlePontuacao.DIFICIL_CORRETO = 0;
		ControlePontuacao.DIFICIL_INCORRETO = 0;
		ControlePontuacao.TOTAL_CORRETO = 0;
		ControlePontuacao.TOTAL_INCORRETO = 0;
		
		salvaPontuacao();
	}
	
	public static void adicionaPontuacaoPalavraCorreta(){
		if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.FACIL){
			++FACIL_CORRETO;
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.MEDIO){
			++MEDIO_CORRETO;
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.DIFICIL){
			++DIFICIL_CORRETO;
		}
		
		++TOTAL_CORRETO;
		salvaPontuacao();
	}
	
	public static void adicionaPontuacaoPalavraIncorreta(){
		if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.FACIL){
			++FACIL_INCORRETO;
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.MEDIO){
			++MEDIO_INCORRETO;
		}else if (ConfiguracaoPreferencias.NIVEL_DIFICULDADE_SELECIONADO == ConfiguracaoPreferencias.DIFICIL){
			++DIFICIL_INCORRETO;
		}
		
		++TOTAL_INCORRETO;
		salvaPontuacao();
	}
	
}
