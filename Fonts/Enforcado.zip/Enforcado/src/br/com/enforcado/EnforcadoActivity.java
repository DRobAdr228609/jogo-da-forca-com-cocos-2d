package br.com.enforcado;

import org.cocos2d.nodes.CCDirector;
import org.cocos2d.opengl.CCGLSurfaceView;

import br.com.enforcado.cenario.tela.CenarioTelaApresentacao;
import br.com.enforcado.componente.ComponenteMenssagem;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoIdioma;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoImagemCaminho;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoSom;
import br.com.enforcado.configuracao.dispositivo.ConfiguracaoPreferencias;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class EnforcadoActivity extends Activity {
	private CCGLSurfaceView configuracaoTela;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 ConfiguracaoPreferencias.delegaContexto(EnforcadoActivity.this);
		 
		//verifica o arquivo de configura��es
		SharedPreferences configuracoeSalva = getSharedPreferences("preferencias" , Context.MODE_PRIVATE);
		
		//busca e adiciona o parametro salvo no arquivo de configura��o, cria uma nova com a op��o defaut caso n�o exista
		ConfiguracaoPreferencias.configuracaoIdioma(configuracoeSalva.getString("idioma", "pt/"));
		ConfiguracaoPreferencias.configuracaoSom(configuracoeSalva.getBoolean("som", true));
		ConfiguracaoPreferencias.configuracaoNivelDificuldade(configuracoeSalva.getInt("dificuldade", 1));
		
		//Adiciona a op��o salva
		ConfiguracaoImagemCaminho.novoIdioma(ConfiguracaoPreferencias.IDIOMA_SELECIONADO);
		
		// definindo orienta��o como landscape
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        
      	//deixa a tela do dispositivo em modo FULL SCREEN
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        //configura a tela
       configuracaoTela = new CCGLSurfaceView(this);
       setContentView(configuracaoTela);
       CCDirector.sharedDirector().attachInView(configuracaoTela);
       
       //configura CCDirector
       CCDirector.sharedDirector().setScreenSize(320, 480);
       
       //abre tela principal
       CCDirector.sharedDirector().runWithScene(CenarioTelaApresentacao.criaCenario());
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		 ConfiguracaoSom.somTema();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		ConfiguracaoSom.paraSomJogo();
	}

	@SuppressLint("NewApi")
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		
		 if(keyCode==KeyEvent.KEYCODE_BACK && event.getRepeatCount()==0){
			 ComponenteMenssagem.menssagem(ConfiguracaoIdioma.TEXTO_OPCAO_VOLTAR_DESABILITADO , Gravity.BOTTOM , Toast.LENGTH_SHORT  , 1);
				 /*CCDirector.sharedDirector().getActivity().setContentView(CCDirector.sharedDirector().getOpenGLView());
				 CCDirector.sharedDirector().getRunningScene().addChild(CenarioTelaSair.criaCenario());
				 CenarioMenuInicio.desabilitaToqueBotoes(false);*/
				 
			    return true;
			  }
		 
		return super.onKeyDown(keyCode, event);
	}
	
}
